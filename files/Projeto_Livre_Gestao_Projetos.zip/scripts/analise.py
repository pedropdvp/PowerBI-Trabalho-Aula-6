"""Calcula os resultados que as medidas DAX devem devolver (para validação e conclusões)."""
import pickle, json
import pandas as pd
# dados.pkl é gerado localmente por gerar_dados.py (fonte confiável)
D = pickle.load(open('/home/user/projeto_livre/scripts/dados.pkl', 'rb'))
c, CORTE = D['clean'], D['corte']
p, k, t, g, o = c['projetos'], c['custos'], c['tarefas'], c['progresso'], c['orcamento']
g = g.copy(); g['Data'] = pd.to_datetime(g['Data'])
last = g[g.Data == g.Data.max()]
p = p.merge(c['gestores'], on='ID_Gestor').merge(c['clientes'], on='ID_Cliente')
p['Dias_Atraso'] = [((r.Data_Fim_Real or max(CORTE, r.Data_Fim_Prevista)) - r.Data_Fim_Prevista).days if r.Data_Fim_Real is None
                    else (r.Data_Fim_Real - r.Data_Fim_Prevista).days for r in p.itertuples()]
ev = last.groupby('ID_Projeto').Valor_Ganho_Acum.sum(); pv = last.groupby('ID_Projeto').Valor_Planeado_Acum.sum()
ac = k.groupby('ID_Projeto').Valor.sum()
p = p.set_index('ID_Projeto'); p['EV'] = ev; p['PV'] = pv; p['AC'] = ac
p['Desvio%'] = p.AC / p.EV - 1; p['SPI'] = p.EV / p.PV
p['Intervir'] = (p.Estado != 'Concluído') & ((p['Desvio%'] > .10) | (p.Dias_Atraso > 30) | (p.SPI < .90))
R = {}
R['intervir'] = p[p.Intervir][['Projeto', 'Gestor', 'Tipo_Projeto', 'Estado', 'Dias_Atraso', 'Desvio%', 'SPI']].sort_values('Desvio%', ascending=False)
def grp(col, df=p):
    x = df.groupby(col)[['EV', 'AC', 'PV']].sum(); x['Desvio%'] = x.AC / x.EV - 1; x['SPI'] = x.EV / x.PV
    x['Desvio€'] = x.AC - x.EV; return x.sort_values('Desvio%', ascending=False)
R['tipo'] = grp('Tipo_Projeto'); R['gestor'] = grp('Gestor')
ph = last.groupby('ID_Fase')[['Valor_Ganho_Acum', 'Valor_Planeado_Acum']].sum().join(k.groupby('ID_Fase').Valor.sum())
ph['Desvio%'] = ph.Valor / ph.Valor_Ganho_Acum - 1
ph = ph.join(t.groupby('ID_Fase').Risco.apply(lambda s: (s == 'Alto').mean()).rename('%Alto')).join(c['fases'].set_index('ID_Fase').Fase)
R['fase'] = ph
cat = o[pd.to_datetime(o.Data).dt.date <= CORTE].groupby('ID_Categoria').Valor_Orcamentado.sum().to_frame().join(k.groupby('ID_Categoria').Valor.sum())
cat['Desvio_vs_plano%'] = cat.Valor / cat.Valor_Orcamentado - 1
R['cat'] = cat.join(c['categorias'].set_index('ID_Categoria'))
R['forn'] = k.groupby('Fornecedor_Tipo').Valor.sum() / k.Valor.sum()
R['tarefas_estado'] = t.Estado.value_counts(); R['tarefas_atrasadas'] = (t.assign(d=[((r.Data_Fim_Real or max(CORTE, r.Data_Fim_Prevista)) - r.Data_Fim_Prevista).days for r in t.itertuples()]).d > 0).mean()
hp = (t.Horas_Previstas * t.Progresso).sum(); R['desvio_horas'] = t.Horas_Reais.sum() / hp - 1
R['tot'] = dict(EV=ev.sum(), PV=pv.sum(), AC=ac.sum(), desvio=ac.sum() / ev.sum() - 1, SPI=ev.sum() / pv.sum(), CPI=ev.sum() / ac.sum(),
                n_intervir=int(p.Intervir.sum()), atrasados=int((p.Dias_Atraso > 0).sum()))
yr = pd.to_datetime(k.Data).dt.year; R['ano'] = k.groupby(yr).Valor.sum()
pd.set_option('display.width', 200)
for kk, v in R.items(): print('==', kk); print(v)
pickle.dump(R, open('/home/user/projeto_livre/scripts/analise.pkl', 'wb'))
