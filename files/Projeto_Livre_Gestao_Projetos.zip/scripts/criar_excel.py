"""Cria o Excel de origem (Dados_Gestao_Projetos.xlsx) e a imagem do modelo de dados."""
import pickle
from datetime import datetime, date
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

BASE = '/home/user/projeto_livre'
# dados.pkl é gerado localmente por gerar_dados.py (fonte confiável)
D = pickle.load(open(f'{BASE}/scripts/dados.pkl', 'rb'))
clean, dirty, CORTE = D['clean'], D['dirty'], D['corte']
RES = pickle.load(open(f'{BASE}/scripts/analise.pkl', 'rb'))  # gerado por analise.py

# ---------------- imagem do modelo em estrela ----------------
F = '/usr/share/fonts/opentype/inter/'
fb, fr, fs = (ImageFont.truetype(F + 'Inter-Bold.otf', 17), ImageFont.truetype(F + 'Inter-Regular.otf', 13),
              ImageFont.truetype(F + 'Inter-SemiBold.otf', 13))
W, H = 1600, 1000
im = Image.new('RGB', (W, H), '#F6F8FB'); d = ImageDraw.Draw(im)
T = {
    'dProjetos': ((330, 30), ['ID_Projeto', 'Projeto', 'Tipo_Projeto', 'Distrito', 'Cliente · Setor', 'Gestor · Departamento',
                              'Data_Fim_Prevista · Data_Fim_Real', 'Orcamento_Contratado', 'Estado', 'Dias_Atraso', 'Situacao_Prazo'], 'dim'),
    'dCalendario': ((1010, 30), ['Date', 'Ano', 'MesNumero', 'Mes', 'MesAno', 'Trimestre', 'AnoMes'], 'dim'),
    'fOrcamento': ((40, 400), ['Data', 'ID_Projeto', 'ID_Fase', 'ID_Categoria', 'Valor_Orcamentado'], 'fact'),
    'fCustos': ((430, 400), ['ID_Movimento', 'Data', 'ID_Projeto', 'ID_Fase', 'ID_Categoria', 'Valor', 'Fornecedor_Tipo', 'Ano_Ficheiro'], 'fact'),
    'fTarefas': ((820, 400), ['ID_Tarefa', 'ID_Projeto', 'ID_Fase', 'Data_Fim_Prevista', 'Data_Fim_Real', 'Horas_Previstas', 'Horas_Reais', 'Estado', 'Risco', 'Dias_Atraso'], 'fact'),
    'fProgresso': ((1210, 400), ['Data', 'ID_Projeto', 'ID_Fase', 'Valor_Planeado_Acum', 'Valor_Ganho_Acum'], 'fact'),
    'dFases': ((560, 790), ['ID_Fase', 'Fase', 'Ordem'], 'dim'),
    'dCategorias': ((140, 790), ['ID_Categoria', 'Categoria'], 'dim'),
    '_Medidas': ((1210, 790), ['42 medidas DAX explícitas'], 'meas'),
}
box = {n: (x, y, 300, 36 + 20 * len(c)) for n, ((x, y), c, k) in T.items()}
facts = ['fOrcamento', 'fCustos', 'fTarefas', 'fProgresso']
links = {'dProjetos': facts, 'dCalendario': facts, 'dFases': facts, 'dCategorias': ['fOrcamento', 'fCustos']}
for dim, fl in links.items():
    dx, dy, dw, dh = box[dim]
    up = dy < 400
    for i, f in enumerate(fl):
        fx, fy, fw, fh = box[f]
        px = fx + fw * (0.3 if up and dim == 'dProjetos' else 0.7 if up else 0.5 + (0.12 if dim == 'dFases' else -0.12))
        py = fy if up else fy + fh
        qx = dx + dw * (i + 1) / (len(fl) + 1); qy = dy + dh if up else dy
        col = '#1D4E89' if dim != 'dCalendario' else '#3B7DD8'
        my = (py + qy) / 2 + {'dProjetos': -20, 'dCalendario': 25, 'dFases': -25 + 12 * i, 'dCategorias': 20 + 12 * i}[dim]
        d.line(((px, py), (px, my), (qx, my), (qx, qy)), fill=col, width=2, joint='curve')
        d.ellipse((qx - 5, qy - 5, qx + 5, qy + 5), fill=col)
        d.text((px + 5, py - 20 if up else py + 4), '*', font=fb, fill='#E07B1F')
# relação inativa fTarefas[Data_Fim_Real] -> dCalendario (tracejada)
fx, fy, fw, fh = box['fTarefas']; dx, dy, dw, dh = box['dCalendario']
pts = [(fx + fw, fy + 130), (fx + fw + 50, fy + 130), (fx + fw + 50, dy + dh + 50), (dx + dw - 20, dy + dh + 50), (dx + dw - 20, dy + dh)]
for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
    n = int(max(abs(x1 - x0), abs(y1 - y0)) / 8)
    for k in range(0, n, 2):
        d.line(((x0 + (x1 - x0) * k / n, y0 + (y1 - y0) * k / n), (x0 + (x1 - x0) * (k + 1) / n, y0 + (y1 - y0) * (k + 1) / n)), fill='#E07B1F', width=2)
for n, ((x, y), cols, kind) in T.items():
    w, h = box[n][2], box[n][3]
    head = {'dim': '#1D4E89', 'fact': '#E07B1F', 'meas': '#5B6577'}[kind]
    d.rounded_rectangle((x + 3, y + 4, x + w + 3, y + h + 4), 10, fill='#DDE3EC')
    d.rounded_rectangle((x, y, x + w, y + h), 10, fill='white', outline='#C9D2E0')
    d.rounded_rectangle((x, y, x + w, y + 32), 10, fill=head); d.rectangle((x, y + 20, x + w, y + 32), fill=head)
    d.text((x + 12, y + 7), n, font=fb, fill='white')
    d.text((x + w - 70, y + 9), {'dim': 'dimensão', 'fact': 'facto', 'meas': 'medidas'}[kind], font=fr, fill='#FFFFFFCC')
    for i, c in enumerate(cols):
        key = (kind == 'dim' and i == 0)
        d.text((x + 14, y + 40 + 20 * i), c + ('   (chave · 1)' if key else ''), font=fs if key else fr, fill='#1D4E89' if key else '#1F2937')
d.text((40, 930), 'Modelo em estrela · relações Many-to-One (* → 1) · filtro numa só direção (dimensão filtra facto) · dCalendario criada em DAX e marcada como tabela de datas', font=fs, fill='#374151')
d.text((40, 954), 'Laranja tracejado = relação INATIVA fTarefas[Data_Fim_Real] → dCalendario[Date], ativada nas medidas com USERELATIONSHIP', font=fs, fill='#E07B1F')
im.save(f'{BASE}/Modelo_Dados_Estrela.png')

# ---------------- Excel ----------------
OUT = f'{BASE}/Dados_Gestao_Projetos.xlsx'
with pd.ExcelWriter(OUT, engine='xlsxwriter', datetime_format='dd/mm/yyyy', date_format='dd/mm/yyyy') as xw:
    wb = xw.book
    h1 = wb.add_format({'bold': True, 'font_size': 18, 'font_color': '#1D4E89'})
    h2 = wb.add_format({'bold': True, 'font_size': 12, 'font_color': '#E07B1F'})
    wrap = wb.add_format({'text_wrap': True, 'valign': 'top'})
    bold = wb.add_format({'bold': True})
    eur = wb.add_format({'num_format': '#,##0.00 €'})
    eur0 = wb.add_format({'num_format': '#,##0 €'})
    pct = wb.add_format({'num_format': '0.0%'})
    dt = wb.add_format({'num_format': 'dd/mm/yyyy'})

    # LEIA-ME
    ws = wb.add_worksheet('LEIA-ME'); ws.set_column('A:A', 4); ws.set_column('B:B', 120)
    linhas = [
        (h1, 'Projeto Livre Power BI — Tema 3: Gestão de Projetos'),
        (None, 'Empresa fictícia: Vértice Construções, S.A. — portefólio de 32 projetos de construção (2024–2025).'),
        (h2, 'Origem dos dados'),
        (None, 'Conjunto de dados FICTÍCIO, gerado com IA/script Python (semente fixa = 2025) para fins de formação. Não representa empresas, clientes ou pessoas reais.'),
        (None, f'Data de corte da análise: {CORTE:%d/%m/%Y}. Período coberto: janeiro de 2024 a dezembro de 2025 (24 meses).'),
        (h2, 'Folhas / Tabelas Excel (importar no Power BI: Obter dados → Excel → selecionar as tabelas t...)'),
        (None, 'tProjetos (Projetos) — 1 linha por projeto: tipo, distrito, cliente, gestor, datas previstas e reais, orçamento contratado, estado.'),
        (None, 'tClientes, tGestores — tabelas auxiliares que são juntas (Merge) a tProjetos no Power Query.'),
        (None, 'tFases, tCategorias — dimensões: fases da obra e categorias de custo.'),
        (None, 'tOrcamento — orçamento planeado por mês × projeto × fase × categoria (facto).'),
        (None, 'tCustos2024 e tCustos2025 — movimentos de custo real, um ficheiro por ano (juntar com Append no Power Query).'),
        (None, 'tTarefas — tarefas de cada projeto com datas previstas/reais, horas, estado e risco (facto).'),
        (None, 'tProgresso — fotografia mensal (fim de mês) do valor planeado (PV) e do valor ganho (EV) acumulados por projeto e fase.'),
        (h2, 'Problemas de qualidade incluídos DE PROPÓSITO (para tratar no Power Query — Etapa A)'),
        (None, '• tProjetos[Tipo_Projeto]: textos em minúsculas e com espaço no fim (ex.: "reabilitação ") → Trim + Capitalize Each Word / Replace Values.'),
        (None, '• tProjetos[Distrito] e tGestores[Gestor]: espaços a mais e nomes em MAIÚSCULAS → Trim + Capitalize Each Word.'),
        (None, '• tCustos: 42 linhas duplicadas (mesmo ID_Movimento), 15 linhas sem Valor e 8 sem ID_Projeto → Remove Duplicates + Remove nulls.'),
        (None, '• tCustos[Fornecedor_Tipo]: algumas linhas em MAIÚSCULAS → Capitalize Each Word.'),
        (None, '• tTarefas: 6 tarefas duplicadas; Estado escrito de formas diferentes ("Concluida", "em curso") → Replace Values; Responsavel com espaços → Trim.'),
        (None, '• Datas de fim real em branco = projeto/tarefa ainda não terminado (não é erro: tratar com colunas condicionais).'),
        (h2, 'Validação'),
        (None, 'A folha "Validacao" tem os totais esperados DEPOIS da limpeza. Use-a para confirmar que as medidas DAX estão corretas (Etapa C).'),
        (None, 'A folha "Modelo_Dados" mostra o esquema em estrela e a lista de relações a criar no Power BI.'),
    ]
    for i, (f, t) in enumerate(linhas, 1):
        ws.write(i, 1, t, f or wrap)

    def table(sheet, df, tname, fmts=None, widths=None):
        df = df.copy()
        for c in df.columns:
            if df[c].map(lambda v: isinstance(v, date)).any():
                df[c] = pd.to_datetime(df[c])
        df.to_excel(xw, sheet_name=sheet, index=False, startrow=0)
        ws = xw.sheets[sheet]
        nr, nc = df.shape
        ws.add_table(0, 0, nr, nc - 1, {'name': tname, 'style': 'Table Style Medium 2',
                                         'columns': [{'header': c} for c in df.columns]})
        for j, c in enumerate(df.columns):
            f = (fmts or {}).get(c)
            if f is None and str(df[c].dtype).startswith('datetime'):
                f = dt
            ws.set_column(j, j, (widths or {}).get(c, max(12, min(40, len(c) + 4))), f)
        ws.freeze_panes(1, 0)

    p = dirty['projetos']
    table('Projetos', p, 'tProjetos', {'Orcamento_Contratado': eur0}, {'Projeto': 38})
    table('Clientes', dirty['clientes'], 'tClientes', widths={'Cliente': 34})
    table('Gestores', dirty['gestores'], 'tGestores', widths={'Gestor': 22})
    table('Fases', dirty['fases'], 'tFases', widths={'Fase': 32})
    table('Categorias', dirty['categorias'], 'tCategorias', widths={'Categoria': 22})
    table('Orcamento', dirty['orcamento'], 'tOrcamento', {'Valor_Orcamentado': eur})
    c = dirty['custos']
    yr = pd.to_datetime(c['Data']).dt.year
    table('Custos_2024', c[yr == 2024], 'tCustos2024', {'Valor': eur})
    table('Custos_2025', c[yr == 2025], 'tCustos2025', {'Valor': eur})
    table('Tarefas', dirty['tarefas'], 'tTarefas', {'Progresso': pct}, {'Tarefa': 30, 'Responsavel': 18})
    table('Progresso', dirty['progresso'], 'tProgresso', {'Valor_Planeado_Acum': eur, 'Valor_Ganho_Acum': eur})

    # Dicionário
    dic = [
        ('tProjetos', 'ID_Projeto', 'Texto', 'Chave do projeto (P01…P32)'), ('tProjetos', 'Tipo_Projeto', 'Texto', 'Residencial, Comercial, Infraestrutura, Reabilitação'),
        ('tProjetos', 'Data_Fim_Prevista', 'Data', 'Data de conclusão contratual'), ('tProjetos', 'Data_Fim_Real', 'Data', 'Data de conclusão real (vazio = não concluído)'),
        ('tProjetos', 'Orcamento_Contratado', 'Decimal (€)', 'Orçamento total aprovado (BAC)'), ('tProjetos', 'Estado', 'Texto', 'Concluído, Em curso, Suspenso'),
        ('tProjetos', 'Prioridade', 'Texto', 'Prioridade estratégica para a administração'),
        ('tOrcamento', 'Data', 'Data', '1.º dia do mês do orçamento'), ('tOrcamento', 'Valor_Orcamentado', 'Decimal (€)', 'Custo planeado no mês'),
        ('tCustos20xx', 'ID_Movimento', 'Texto', 'Chave do movimento de custo'), ('tCustos20xx', 'Valor', 'Decimal (€)', 'Custo real registado'),
        ('tCustos20xx', 'Fornecedor_Tipo', 'Texto', 'Interno, Fornecedor, Subempreiteiro'),
        ('tTarefas', 'Horas_Previstas / Horas_Reais', 'Inteiro', 'Esforço planeado e consumido'), ('tTarefas', 'Progresso', 'Decimal (0–1)', '% físico da tarefa'),
        ('tTarefas', 'Estado', 'Texto', 'Concluída, Em curso, Bloqueada, Por iniciar'), ('tTarefas', 'Risco', 'Texto', 'Baixo, Médio, Alto'),
        ('tProgresso', 'Valor_Planeado_Acum', 'Decimal (€)', 'PV — valor do trabalho que devia estar feito até à data'),
        ('tProgresso', 'Valor_Ganho_Acum', 'Decimal (€)', 'EV — valor orçamentado do trabalho efetivamente feito até à data'),
    ]
    pd.DataFrame(dic, columns=['Tabela', 'Coluna', 'Tipo', 'Descrição']).to_excel(xw, sheet_name='Dicionario', index=False)
    xw.sheets['Dicionario'].set_column('A:C', 22); xw.sheets['Dicionario'].set_column('D:D', 70)

    # Modelo
    ws = wb.add_worksheet('Modelo_Dados')
    ws.write(0, 0, 'Modelo de dados em estrela', h1)
    rel = [('fOrcamento[ID_Projeto]', 'dProjetos[ID_Projeto]', '*:1', 'Ativa', 'Única'), ('fCustos[ID_Projeto]', 'dProjetos[ID_Projeto]', '*:1', 'Ativa', 'Única'),
           ('fTarefas[ID_Projeto]', 'dProjetos[ID_Projeto]', '*:1', 'Ativa', 'Única'), ('fProgresso[ID_Projeto]', 'dProjetos[ID_Projeto]', '*:1', 'Ativa', 'Única'),
           ('fOrcamento[ID_Fase]', 'dFases[ID_Fase]', '*:1', 'Ativa', 'Única'), ('fCustos[ID_Fase]', 'dFases[ID_Fase]', '*:1', 'Ativa', 'Única'),
           ('fTarefas[ID_Fase]', 'dFases[ID_Fase]', '*:1', 'Ativa', 'Única'), ('fProgresso[ID_Fase]', 'dFases[ID_Fase]', '*:1', 'Ativa', 'Única'),
           ('fOrcamento[ID_Categoria]', 'dCategorias[ID_Categoria]', '*:1', 'Ativa', 'Única'), ('fCustos[ID_Categoria]', 'dCategorias[ID_Categoria]', '*:1', 'Ativa', 'Única'),
           ('fOrcamento[Data]', 'dCalendario[Date]', '*:1', 'Ativa', 'Única'), ('fCustos[Data]', 'dCalendario[Date]', '*:1', 'Ativa', 'Única'),
           ('fProgresso[Data]', 'dCalendario[Date]', '*:1', 'Ativa', 'Única'), ('fTarefas[Data_Fim_Prevista]', 'dCalendario[Date]', '*:1', 'Ativa', 'Única'),
           ('fTarefas[Data_Fim_Real]', 'dCalendario[Date]', '*:1', 'INATIVA (USERELATIONSHIP)', 'Única')]
    for j, hname in enumerate(['De (lado muitos)', 'Para (lado um)', 'Cardinalidade', 'Estado', 'Direção do filtro']):
        ws.write(2, j, hname, bold)
    for i, r in enumerate(rel, 3):
        ws.write_row(i, 0, r)
    ws.set_column('A:B', 30); ws.set_column('C:E', 24)
    ws.insert_image(20, 0, f'{BASE}/Modelo_Dados_Estrela.png', {'x_scale': 0.75, 'y_scale': 0.75})

    # Validação (valores limpos)
    pr = clean['projetos']; cu = clean['custos']; ta = clean['tarefas']; pg = clean['progresso']; ob = clean['orcamento']
    last = pg[pg.Data == pg.Data.max()]
    ev, pv, ac = last.Valor_Ganho_Acum.sum(), last.Valor_Planeado_Acum.sum(), cu.Valor.sum()
    atraso = [((r.Data_Fim_Real or max(CORTE, r.Data_Fim_Prevista)) - r.Data_Fim_Prevista).days for r in pr.itertuples()]
    atr = [a for a in atraso if a > 0]
    cy = pd.to_datetime(cu.Data).dt.year; oy = pd.to_datetime(ob.Data).dt.year
    vals = [
        ('Nº Projetos', len(pr), None), ('Projetos Concluídos', int((pr.Estado == 'Concluído').sum()), None),
        ('Projetos Atrasados (Dias_Atraso > 0)', len(atr), None), ('% Projetos Atrasados', len(atr) / len(pr), pct),
        ('Dias de Atraso Médio (projetos atrasados)', round(sum(atr) / len(atr), 1), None),
        ('Orçamento Contratado (BAC)', pr.Orcamento_Contratado.sum(), eur0), ('Orçamento Planeado total (tOrcamento)', ob.Valor_Orcamentado.sum(), eur0),
        ('Orçamento Planeado 2024', ob[oy == 2024].Valor_Orcamentado.sum(), eur0), ('Orçamento Planeado 2025', ob[oy == 2025].Valor_Orcamentado.sum(), eur0),
        ('Custo Real total (após limpeza)', ac, eur0), ('Custo Real 2024', cu[cy == 2024].Valor.sum(), eur0), ('Custo Real 2025', cu[cy == 2025].Valor.sum(), eur0),
        ('Nº movimentos de custo (após limpeza)', len(cu), None),
        ('Valor Planeado acumulado PV (31/12/2025)', pv, eur0), ('Valor Ganho acumulado EV (31/12/2025)', ev, eur0),
        ('Desvio de Custo € (Custo Real − EV)', ac - ev, eur0), ('Desvio de Custo % (Custo Real / EV − 1)', ac / ev - 1, pct),
        ('CPI (EV / Custo Real)', round(ev / ac, 3), None), ('SPI (EV / PV)', round(ev / pv, 3), None),
        ('Nº Tarefas (após remover duplicados)', len(ta), None), ('Tarefas Alto Risco', int((ta.Risco == 'Alto').sum()), None),
        ('Tarefas Bloqueadas', int((ta.Estado == 'Bloqueada').sum()), None),
        ('Projetos Intervenção Prioritária', RES['tot']['n_intervir'], None),
        ('Desvio de Horas %', RES['desvio_horas'], pct),
    ]
    ws = wb.add_worksheet('Validacao')
    ws.write(0, 0, 'Totais esperados depois da limpeza no Power Query (sem filtros)', h1)
    ws.write_row(2, 0, ['Indicador', 'Valor esperado'], bold)
    for i, (n, v, f) in enumerate(vals, 3):
        ws.write(i, 0, n); ws.write(i, 1, v, f)
    ws.set_column('A:A', 48); ws.set_column('B:B', 20)
print('ok', OUT)
