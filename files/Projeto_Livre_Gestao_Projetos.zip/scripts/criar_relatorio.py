"""Cria o documento Word do Projeto Livre (proposta, resumo executivo, documentação, conclusões, nota de IA)."""
import json, pickle
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = '/home/user/projeto_livre'
MOD = json.load(open(f'{BASE}/scripts/modelo.json', encoding='utf-8'))
R = pickle.load(open(f'{BASE}/scripts/analise.pkl', 'rb'))  # gerado localmente por analise.py
T = R['tot']
NAVY, ORANGE, GREY = RGBColor(0x1D, 0x4E, 0x89), RGBColor(0xE0, 0x7B, 0x1F), RGBColor(0x55, 0x5F, 0x6D)


def eur(v):
    return f'{v / 1e6:,.1f} M€'.replace(',', ' ').replace('.', ',')


def pc(v, d=1):
    return f'{v * 100:.{d}f} %'.replace('.', ',')


def num(v, d=2):
    return f'{v:.{d}f}'.replace('.', ',')


doc = Document()
st = doc.styles['Normal']; st.font.name = 'Calibri'; st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
for s, size, color in (('Heading 1', 16, NAVY), ('Heading 2', 13, ORANGE), ('Heading 3', 11, NAVY)):
    doc.styles[s].font.size = Pt(size); doc.styles[s].font.color.rgb = color; doc.styles[s].font.name = 'Calibri'
sec = doc.sections[0]
sec.left_margin = sec.right_margin = Cm(2); sec.top_margin = sec.bottom_margin = Cm(1.8)


def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement('w:shd')
    sh.set(qn('w:val'), 'clear'); sh.set(qn('w:color'), 'auto'); sh.set(qn('w:fill'), hexcolor); tcPr.append(sh)


def table(rows, header=True, widths=None, size=9):
    t = doc.add_table(rows=len(rows), cols=len(rows[0])); t.style = 'Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            c = t.cell(i, j); c.text = ''
            run = c.paragraphs[0].add_run(str(v)); run.font.size = Pt(size)
            if header and i == 0:
                run.bold = True; run.font.color.rgb = RGBColor(255, 255, 255); shade(c, '1D4E89')
            if widths:
                c.width = Cm(widths[j])
    doc.add_paragraph()
    return t


def p(text, bold=False, italic=False, color=None, size=None, style=None):
    par = doc.add_paragraph(style=style)
    r = par.add_run(text); r.bold = bold; r.italic = italic
    if color:
        r.font.color.rgb = color
    if size:
        r.font.size = Pt(size)
    return par


def bullets(items, style='List Bullet'):
    for n, it in enumerate(items, 1):
        if style == 'List Number':   # numeração manual: recomeça em 1 em cada lista
            par = doc.add_paragraph(); par.paragraph_format.left_indent = Cm(0.9); par.paragraph_format.first_line_indent = Cm(-0.6)
            par.add_run(f'{n}.  ').bold = True
        else:
            par = doc.add_paragraph(style=style)
        if isinstance(it, tuple):
            par.add_run(it[0]).bold = True; par.add_run(it[1])
        else:
            par.add_run(it)


def code(text):
    par = doc.add_paragraph()
    r = par.add_run(text); r.font.name = 'Consolas'; r.font.size = Pt(8)
    r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Consolas')
    pPr = par._p.get_or_add_pPr(); sh = OxmlElement('w:shd'); sh.set(qn('w:val'), 'clear'); sh.set(qn('w:fill'), 'F2F4F7'); pPr.append(sh)


tipo, gest, fase, cat = R['tipo'], R['gestor'], R['fase'], R['cat']
reab = tipo.loc['Reabilitação']; infra = tipo.loc['Infraestrutura']
f5 = fase.loc['F5']; top_g = gest.index[0]; tg = gest.iloc[0]
k3 = cat.loc['K3']
interv = R['intervir']
n_int = len(interv)
g_int = interv.Gestor.value_counts()

# ---------------- capa ----------------
t = doc.add_paragraph(); t.alignment = WD_ALIGN_PARAGRAPH.LEFT
r = t.add_run('Projeto Livre — Dashboard em Power BI'); r.bold = True; r.font.size = Pt(24); r.font.color.rgb = NAVY
p('Tema 3 — Gestão de Projetos · Vértice Construções, S.A. (empresa fictícia)', bold=True, color=ORANGE, size=13)
p('Portefólio de 32 projetos de construção · janeiro de 2024 a dezembro de 2025 · data de corte 31/12/2025', color=GREY)
p('Formando: ______________________________    Data: ____/____/______', color=GREY)
doc.add_paragraph()
p('Conteúdo', bold=True, color=NAVY, size=12)
bullets(['Anexo A — Proposta inicial', '1. Resumo executivo (1 página)', '2. Etapa A — Dados e Power Query', '3. Etapa B — Modelo de dados',
         '4. Etapa C — Medidas DAX', '5. Etapa D — Dashboard', '6. Etapa E — Conclusões e recomendações', '7. Validação dos cálculos',
         '8. Como abrir o projeto no Power BI', 'Anexo B — Nota de utilização de IA', 'Anexo C — Lista de verificação final',
         'Apêndice — Código Power Query (M) completo'])
doc.add_page_break()

# ---------------- Anexo A ----------------
doc.add_heading('Anexo A — Proposta inicial', 1)
table([['Campo', 'Proposta'],
       ['Tema escolhido', 'Tema 3 — Gestão de Projetos (portefólio de obras de uma empresa de construção).'],
       ['Problema de negócio', 'A empresa gere 32 projetos em simultâneo e não sabe, de forma rápida, quais estão atrasados, quais gastam acima do orçamento e onde estão as causas (fase, tipo de obra, gestor).\nAs decisões de intervenção chegam tarde.'],
       ['Quem vai utilizar a dashboard e que decisões precisa de tomar', 'Diretor de Projetos / Gestor de Portefólio. Decide em que projetos intervir primeiro, onde reforçar equipas ou subempreiteiros, revê orçamentos e contingências e como distribui os projetos pelos gestores.'],
       ['Três perguntas de negócio', '1) Que projetos estão atrasados e quais exigem intervenção prioritária?\n2) Onde estão os maiores desvios orçamentais (tipo, fase, categoria, gestor)?\n3) Como se compara o progresso previsto com o real ao longo do tempo?'],
       ['Indicadores (KPIs) que considero relevantes', 'Nº de projetos;\n% de projetos atrasados;\ndias de atraso médio;\ncusto real vs orçamento;\ndesvio de custo (€ e %);\nCPI;\nSPI;\nprogresso previsto vs real;\nnº de projetos a intervir;\n% de tarefas de risco alto.'],
       ['Dataset previsto (fonte) e tabelas necessárias', 'Conjunto fictício em Excel, gerado com IA (indicado).\nTabelas:\nProjetos,\nClientes,\nGestores,\nFases,\nCategorias,\nOrçamento mensal,\nCustos 2024 e 2025,\nTarefas e Progresso mensal.']],
      widths=[4.5, 12.5])
doc.add_page_break()

# ---------------- 1. Resumo executivo ----------------
doc.add_heading('1. Resumo executivo', 1)
p('Objetivo. ', bold=True).add_run('Dar ao Diretor de Projetos uma visão única do portefólio para identificar, em minutos, os projetos atrasados ou com derrapagem de custos, '
                                    'perceber as causas e decidir onde intervir.').bold = False
p('Público-alvo. ', bold=True).add_run('Diretor de Projetos e gestores de portefólio (reunião mensal de acompanhamento).').bold = False
p('KPIs principais (31/12/2025, sem filtros)', bold=True, color=NAVY)
table([['Indicador', 'Valor', 'Leitura'],
       ['Nº de projetos', '32', '16 concluídos, 15 em curso, 1 suspenso'],
       ['% de projetos atrasados', pc(T['atrasados'] / 32, 0), f'{T["atrasados"]} projetos terminaram ou vão terminar depois do prazo'],
       ['Custo real acumulado', eur(T['AC']), f'Valor ganho (trabalho feito, a preços de orçamento): {eur(T["EV"])}'],
       ['Desvio de custo', '+' + pc(T['desvio']), f'Gastaram-se mais {eur(T["AC"] - T["EV"])} do que o orçamentado para o trabalho realizado'],
       ['SPI · índice de prazo', num(T['SPI']), f'Está feito {pc(T["SPI"], 0)} do trabalho que devia estar feito'],
       ['Projetos a intervir', str(T['n_intervir']), 'Desvio > 10 %, atraso > 30 dias ou SPI < 0,90']],
      widths=[4.5, 3, 9.5])
p('Três conclusões', bold=True, color=NAVY)
bullets([
    ('Reabilitação é o tipo de obra mais crítico: ', f'desvio de custo de +{pc(reab["Desvio%"])} e SPI de {num(reab["SPI"])}, contra +{pc(infra["Desvio%"])} nas obras de infraestrutura.'),
    ('A fase de Instalações Técnicas concentra a derrapagem: ', f'+{pc(f5["Desvio%"])} de desvio (a média do portefólio é +{pc(T["desvio"])}) e a maior proporção de tarefas de risco alto ({pc(f5["%Alto"], 0)}).'),
    ('O desempenho depende do gestor: ', f'os projetos de {top_g} têm +{pc(tg["Desvio%"])} de desvio e {g_int.get(top_g, 0)} dos {n_int} projetos a intervir; o gestor com melhor resultado fica em +{pc(gest["Desvio%"].min())}.'),
], 'List Number')
p('Problema / risco identificado', bold=True, color=NAVY)
p(f'As subempreitadas são a categoria com maior desvio face ao plano (+{pc(k3["Desvio_vs_plano%"])}) e pesam mais de metade do orçamento das Instalações Técnicas. '
  'Sem controlo, a derrapagem dos projetos em curso vai continuar até ao fim das obras, reduzindo a margem.')
p('Duas recomendações', bold=True, color=NAVY)
bullets([
    ('Rever a contratação das Instalações Técnicas: ', 'adjudicar as subempreitadas com preço fechado e revisão do projeto de especialidades antes do arranque, e criar um ponto de controlo de custos no início desta fase.'),
    ('Reunião quinzenal para os projetos a intervir: ', f'começar pelos {n_int} projetos da tabela da página 1. Reforçar o acompanhamento dos projetos de {top_g} (gestor com menos experiência) e prever uma contingência de 15 a 20 % nas futuras obras de reabilitação.'),
], 'List Number')
p('Como a dashboard ajuda a decidir. ', bold=True).add_run('A página 1 mostra o estado do portefólio e a lista de projetos a intervir, já ordenada pelo desvio. '
                                                             'A página 2 explica as causas por fase, tarefa, risco e gestor. Os segmentadores permitem repetir a análise por ano, tipo, gestor ou estado.').bold = False
doc.add_page_break()

# ---------------- 2. Etapa A ----------------
doc.add_heading('2. Etapa A — Obter e preparar os dados', 1)
doc.add_heading('Origem e adequação', 2)
p('Fonte: conjunto de dados fictício criado em Excel (Dados_Gestao_Projetos.xlsx), gerado com IA/script Python com semente fixa. Não representa empresas nem pessoas reais. '
  'Licença: uso livre para formação.')
table([['Critério do guia', 'Cumpre?', 'Evidência'],
       ['Coluna de datas com 12+ meses', 'Sim', '24 meses de custos (jan/2024 a dez/2025); orçamento até 2026'],
       ['Medida numérica + 2 categorias', 'Sim', 'Valores €, horas e dias; tipo de projeto, fase, categoria, gestor, distrito, estado'],
       ['Volume e não agregado', 'Sim', '5 925 movimentos de custo, 3 530 linhas de orçamento, 635 tarefas e 3 262 fotografias de progresso (após limpeza)'],
       ['Valores credíveis', 'Sim, sintético', 'Sem datas impossíveis nem valores negativos; dataset sintético (indicado)'],
       ['Fonte e licença', 'Sim', 'Indicadas acima e na folha LEIA-ME do Excel']], widths=[5, 2.5, 9.5])
doc.add_heading('Problemas de qualidade e tratamento no Power Query', 2)
table([['Tabela', 'Problema', 'Passo no Power Query'],
       ['tProjetos', 'Tipo_Projeto em minúsculas e com espaço ("reabilitação ")', 'Transform → Trim + Capitalize Each Word (Text.Proper)'],
       ['tProjetos', 'Distrito com espaços à esquerda', 'Trim + Capitalize Each Word'],
       ['tGestores', 'Nomes com espaços e em MAIÚSCULAS', 'Trim + Capitalize Each Word'],
       ['tCustos2024 / 2025', 'Custos separados por ano', 'Append (Table.Combine) + coluna Ano_Ficheiro'],
       ['tCustos', '42 linhas duplicadas', 'Remove Duplicates (Table.Distinct)'],
       ['tCustos', '15 linhas sem Valor e 8 sem ID_Projeto', 'Remove Empty / filtro "não é nulo"'],
       ['tCustos', 'Fornecedor_Tipo com textos em MAIÚSCULAS', 'Capitalize Each Word (antes de remover duplicados)'],
       ['tTarefas', 'Estado: "Concluida", "em curso"', 'Replace Values → "Concluída", "Em curso"'],
       ['tTarefas', 'Responsavel com espaços; 6 tarefas duplicadas', 'Trim + Remove Duplicates'],
       ['tProjetos + tClientes + tGestores', 'Informação de cliente e gestor noutras tabelas', 'Merge Queries (Left Outer) e expandir colunas → dimensão dProjetos'],
       ['dProjetos / fTarefas', 'Falta o atraso', 'Custom Column Dias_Atraso + Conditional Column Situacao_Prazo / Atrasada']],
      widths=[3.5, 6.5, 7])
p('As consultas tClientes e tGestores ficam como consultas auxiliares (stg_…) sem carregamento (Enable load desligado). Assim o modelo fica em estrela e não em floco de neve. '
  'O caminho do ficheiro e a data de corte são parâmetros (CaminhoExcel, DataCorte), o que torna as consultas reutilizáveis.')
doc.add_heading('Exemplo — coluna personalizada Dias_Atraso (M)', 3)
code('= if [Data_Fim_Real] <> null\n  then Duration.Days([Data_Fim_Real] - [Data_Fim_Prevista])\n  else List.Max({0, Duration.Days(DataCorte - [Data_Fim_Prevista])})')
p('O código M completo de todas as consultas está no Apêndice.', italic=True, color=GREY)

# ---------------- 3. Etapa B ----------------
doc.add_heading('3. Etapa B — Modelo de dados', 1)
doc.add_picture(f'{BASE}/Modelo_Dados_Estrela.png', width=Cm(17))
bullets(['4 tabelas de factos (fOrcamento, fCustos, fTarefas, fProgresso) e 4 dimensões partilhadas (dProjetos, dFases, dCategorias, dCalendario).',
         'Todas as relações são Many-to-One (*:1), com filtro numa só direção (a dimensão filtra o facto). Não há relações ambíguas.',
         'fTarefas tem duas datas: Data_Fim_Prevista (relação ativa) e Data_Fim_Real (relação inativa, a tracejado). A relação inativa é usada na medida Tarefas Concluídas (data real) com USERELATIONSHIP.',
         'dCalendario foi criada em DAX (Etapa B do guia), com anos completos, e marcada como tabela de datas (Mark as date table → Date).',
         'As medidas estão todas na tabela _Medidas, organizadas por pastas (Portefólio, Orçamento vs Real, Valor Ganho, Inteligência Temporal, Tarefas, Intervenção).'])
doc.add_heading('Tabela Calendário (DAX)', 3)
code('dCalendario =\n' + MOD['tables']['dCalendario']['src'])
p('Ordenação: Mes é ordenado por MesNumero e MesAno por AnoMes (Sort by column). dFases[Fase] é ordenada por Ordem.', color=GREY, size=9)

# ---------------- 4. Etapa C ----------------
doc.add_heading('4. Etapa C — Medidas DAX', 1)
p(f'Foram criadas {len(MOD["measures"])} medidas explícitas na tabela _Medidas. O modelo tem "discourage implicit measures" ativo, para obrigar ao uso de medidas.')
doc.add_heading('Conceito usado: Valor Ganho (Earned Value)', 3)
p('Comparar só "orçamento até à data" com "custo real" engana: um projeto atrasado gasta menos do que o planeado e parece poupar dinheiro. '
  'Por isso, o desvio orçamental principal compara o custo real com o Valor Ganho (EV), o valor orçamentado do trabalho efetivamente feito. '
  'CPI = EV ÷ Custo real (abaixo de 1 = acima do orçamento). SPI = EV ÷ Valor planeado (abaixo de 1 = atrasado). '
  'A comparação simples orçamento vs real também existe (medidas Desvio vs Orçamento € e %), como pede o requisito do tema.')
rows = [['Pasta', 'Medida', 'DAX']]
for folder, name, expr, fmt, desc in MOD['measures']:
    rows.append([folder.split('. ', 1)[1], name, expr])
t = table(rows, widths=[2.8, 4.2, 10], size=7.5)
doc.add_heading('Duas medidas para explicar na apresentação', 2)
p('1) Valor Ganho (EV) — medida semi-aditiva', bold=True)
code([m for m in MOD['measures'] if m[1] == 'Valor Ganho (EV)'][0][2])
p('fProgresso guarda uma fotografia acumulada no fim de cada mês. Somar todos os meses daria um valor errado. A variável UltimaData encontra a última fotografia no contexto '
  '(por exemplo, o último mês do ano escolhido no segmentador) e o CALCULATE soma apenas essa data. A medida responde a todos os filtros: projeto, fase, gestor e ano.')
p('2) Projetos Intervenção Prioritária — FILTER com transição de contexto', bold=True)
code([m for m in MOD['measures'] if m[1] == 'Projetos Intervenção Prioritária'][0][2])
p('FILTER percorre cada projeto. Dentro dele, as medidas [Desvio de Custo %] e [SPI] são calculadas para esse projeto (transição de contexto). '
  'São contados os projetos não concluídos que cumprem pelo menos um critério. É a medida que transforma a análise numa decisão: em que projetos intervir.')

# ---------------- 5. Etapa D ----------------
doc.add_heading('5. Etapa D — Dashboard (2 páginas)', 1)
p('Esquema do layout (as caixas mostram a posição e os campos de cada visual):', italic=True, color=GREY, size=9)
doc.add_picture(f'{BASE}/Preview_pg_visao_geral.png', width=Cm(17))
table([['Visual (página 1 — Visão Geral)', 'Pergunta a que responde', 'Porquê este visual'],
       ['6 cartões KPI', 'Como está o portefólio?', 'Leitura imediata do mais importante, no topo'],
       ['Colunas + linha: custo real vs orçamento por mês', 'Como evoluem os custos no tempo?', 'Compara duas séries de natureza diferente no mesmo eixo temporal'],
       ['Barras: desvio de custo % por tipo de projeto', 'Que tipo de obra derrapa mais?', 'Barras horizontais ordenadas facilitam o ranking'],
       ['Tabela com semáforo', 'Em que projetos intervir?', 'Lista acionável com cor condicional (verde/amarelo/vermelho)'],
       ['Linhas: progresso previsto vs real', 'Estamos a cumprir o plano?', 'O afastamento das duas linhas mostra o atraso acumulado']], widths=[5.5, 5, 6.5])
doc.add_picture(f'{BASE}/Preview_pg_prazos_riscos.png', width=Cm(17))
table([['Visual (página 2 — Prazos e Riscos)', 'Pergunta a que responde', 'Porquê este visual'],
       ['6 cartões KPI de tarefas e índices', 'Qual é a dimensão do problema?', 'Contexto antes do detalhe'],
       ['Colunas: desvio % e % tarefas risco alto por fase', 'Que fases representam maior risco?', 'Fases na ordem da obra; compara custo e risco'],
       ['Matriz fase × risco', 'Quantas tarefas de cada nível de risco por fase?', 'Detalhe numérico para validar o gráfico'],
       ['Dispersão: atraso vs desvio (tamanho = orçamento)', 'Que projetos estão nos dois problemas?', 'O canto superior direito mostra os casos prioritários'],
       ['Anel: tarefas por estado; barras: desvio por gestor', 'Onde está a execução e quem precisa de apoio?', 'Composição simples e ranking por responsável']], widths=[5.5, 5, 6.5])
bullets(['Navegação: botões "01 Visão Geral" e "02 Prazos e Riscos" na barra lateral; o botão da página atual fica a laranja.',
         'Botão "Limpar todos os filtros" (ação Clear all slicers).',
         'Segmentadores: Ano, Tipo de projeto, Gestor, Estado do projeto e Fase da obra.',
         'Formatação coerente: tema escuro, unidades nos títulos (€, %, dias), cores fixas (laranja = real, azul = planeado).'])

# ---------------- 6. Etapa E ----------------
doc.add_heading('6. Etapa E — Interpretação dos resultados', 1)
doc.add_heading('Conclusões', 2)
rows = [['Tipo de projeto', 'Desvio de custo %', 'SPI', 'Desvio €']] + [[i, '+' + pc(r['Desvio%']), num(r['SPI']), eur(r['Desvio€'])] for i, r in tipo.iterrows()]
table(rows, widths=[5, 4, 3, 5])
rows = [['Fase', 'Desvio de custo %', '% tarefas risco alto']] + [[r['Fase'], '+' + pc(r['Desvio%']), pc(r['%Alto'], 0)] for _, r in fase.iterrows()]
table(rows, widths=[7, 5, 5])
rows = [['Gestor', 'Desvio de custo %', 'SPI', 'Projetos a intervir']] + [[i, '+' + pc(r['Desvio%']), num(r['SPI']), str(g_int.get(i, 0))] for i, r in gest.iterrows()]
table(rows, widths=[5, 4, 3, 5])
bullets([
    f'Reabilitação tem o pior desempenho de custo (+{pc(reab["Desvio%"])}) e de prazo (SPI {num(reab["SPI"])}): é o tipo de obra com mais imprevistos (estado do edificado existente).',
    f'Instalações Técnicas é a fase com maior desvio (+{pc(f5["Desvio%"])}) e é onde começam os atrasos das fases seguintes (Acabamentos e Entrega).',
    f'{top_g} acumula o maior desvio (+{pc(tg["Desvio%"])}) e {g_int.get(top_g, 0)} dos {n_int} projetos a intervir. Os seus projetos são sobretudo reabilitações e hotelaria em centros históricos.',
], 'List Number')
doc.add_heading('Problema, risco ou oportunidade', 2)
p(f'Risco: {n_int} dos 16 projetos não concluídos já cumprem pelo menos um critério de intervenção. O desvio total é de {eur(T["AC"] - T["EV"])} (+{pc(T["desvio"])}). '
  f'As subempreitadas derrapam +{pc(k3["Desvio_vs_plano%"])} face ao plano. Se o CPI de {num(T["CPI"], 2)} se mantiver, o custo final das obras em curso ficará cerca de {pc(1 / T["CPI"] - 1, 0)} acima do orçamento.')
doc.add_heading('Recomendações', 2)
bullets([('Instalações Técnicas: ', 'preço fechado nas subempreitadas, revisão do projeto de especialidades antes do arranque e um ponto de controlo de custos à entrada da fase. Acompanhar na página 2 com o filtro Fase = Instalações Técnicas.'),
         ('Gestão do portefólio: ', f'reunião quinzenal sobre os {n_int} projetos a intervir, começando pelos de maior desvio. Dar apoio/mentoria a {top_g} e incluir 15 a 20 % de contingência nos orçamentos de reabilitação.')], 'List Number')
doc.add_heading('Como a dashboard ajuda o responsável', 2)
p('Em vez de folhas de cálculo por obra, o Diretor de Projetos vê numa página onde estão os problemas (KPIs e tabela de intervenção) e, na segunda, porquê (fase, risco, gestor). '
  'Os índices CPI e SPI permitem comparar projetos de dimensões diferentes. A lista de intervenção dá a ordem de prioridade para a reunião de acompanhamento.')

# ---------------- 7. Validação ----------------
doc.add_heading('7. Validação dos cálculos', 1)
p('Os totais esperados (calculados fora do Power BI, depois da limpeza) estão na folha "Validacao" do Excel. No Power BI, sem filtros, as medidas devem devolver:')
table([['Medida', 'Valor esperado'], ['Nº Projetos', '32'], ['Projetos Atrasados', str(T['atrasados'])], ['Custo Real (total)', eur(T['AC'])],
       ['Custo Real 2024 / 2025', f'{eur(R["ano"][2024])} / {eur(R["ano"][2025])}'], ['Valor Ganho (EV)', eur(T['EV'])],
       ['Desvio de Custo %', '+' + pc(T['desvio'])], ['CPI / SPI', f'{num(T["CPI"], 3)} / {num(T["SPI"], 3)}'],
       ['Projetos Intervenção Prioritária', str(T['n_intervir'])], ['Nº Tarefas', '635'], ['Desvio de Horas %', '+' + pc(R['desvio_horas'])]], widths=[8, 8])
p('Teste dos segmentadores: ao escolher Tipo = Reabilitação, o Desvio de Custo % deve passar para +' + pc(reab['Desvio%']) + '; com Fase = Instalações Técnicas, para +' + pc(f5['Desvio%']) + '.')

# ---------------- 8. Como abrir ----------------
doc.add_heading('8. Como abrir o projeto no Power BI', 1)
bullets(['Extrair o ZIP para C:\\PowerBI\\Projeto_Livre\\ (o Excel fica em C:\\PowerBI\\Projeto_Livre\\Dados_Gestao_Projetos.xlsx).',
         'Abrir PowerBI\\Gestao_Projetos.pbip no Power BI Desktop (versão recente). Se aparecer um aviso sobre funcionalidades de pré-visualização, ativar em '
         'Ficheiro → Opções → Funcionalidades de pré-visualização: "Power BI Project (.pbip)", "TMDL" e "PBIR"; depois reiniciar.',
         'Se o Excel estiver noutra pasta: Base → Transformar dados → Editar parâmetros → CaminhoExcel.',
         'Base → Atualizar, para carregar os dados.',
         'Confirmar no Modelo que dCalendario está marcada como tabela de datas e que as relações estão como no esquema.',
         'Ficheiro → Guardar como → .pbix, para entregar (o guia pede um .pbix).',
         'Alternativa: criar tudo à mão num .pbix novo com o código M (Apêndice) e as medidas DAX (secção 4). É também uma boa forma de preparar a defesa oral.'], 'List Number')

# ---------------- Anexo B ----------------
doc.add_heading('Anexo B — Nota de utilização de IA', 1)
table([['Campo', 'Resposta'],
       ['Uso da IA', 'Geração do dataset fictício em Excel (com erros de qualidade propositados), finalização do modelo de dados, das consultas Power Query, das medidas DAX, do layout inicial da dashboard e de uma primeira versão das conclusões.'],
       ['Alterações feitas depois de validar os resultados', 'Algumas das medidas estavam com incorreções e tiveram de ser alteradas.'],
       ['O que fiz sem ajuda da IA', 'Todo o pensamento estruturado de como o modelo de dados deve ser e quais as relações entre as várias tabelas.\nEspecificar muito bem quais os objetivos deste projeto e o que deveria incluir obrigatoriamente.']], widths=[5, 12])

# ---------------- Anexo C ----------------
doc.add_heading('Anexo C — Lista de verificação final', 1)
for it in ['Público-alvo e decisões identificados no resumo executivo', 'Dados limpos no Power Query e fonte indicada (fictícia, gerada com IA)',
           'Relações corretas e dCalendario marcada como tabela de datas', f'{len(MOD["measures"])} medidas explícitas (≥ 10), com comparação, variação e percentagem',
           'Valores mudam corretamente com os segmentadores (testar)', '2 páginas, 6 KPIs por página, ≥ 4 visualizações, títulos e unidades, navegação e botão limpar filtros',
           '3 conclusões, 1 risco e 2 recomendações', 'Entregar: .pbix, Excel de dados, resumo executivo, proposta inicial e nota de IA']:
    par = doc.add_paragraph(); par.add_run('☐  ' + it)

# ---------------- Apêndice ----------------
doc.add_page_break()
doc.add_heading('Apêndice — Código Power Query (M)', 1)
p('Parâmetros: CaminhoExcel (texto, caminho do Excel) e DataCorte (data, 31/12/2025). Consultas auxiliares não carregadas: stg_Clientes e stg_Gestores (fazem Trim / Capitalize Each Word e são juntas a dProjetos com Merge).', size=9)
for tn, tv in MOD['tables'].items():
    if tv['kind'] == 'm':
        doc.add_heading(tn, 3); code(tv['src'])
doc.save(f'{BASE}/Relatorio_Projeto_Livre_Gestao_Projetos.docx')
print('ok')
