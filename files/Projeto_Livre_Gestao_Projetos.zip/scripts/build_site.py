"""Gera site/index.html (versão pública do dossiê) a partir de dashboard/index.html."""
S = '/home/user/projeto_livre/site'
body = open('/home/user/projeto_livre/dashboard/index.html').read()
shim = '<script>window.PL_STATIC={files:{zip:"files/Projeto_Livre_Gestao_Projetos.zip",pbix:"files/Gestao_Projetos.pbix",xlsx:"files/Dados_Gestao_Projetos.xlsx",docx:"files/Relatorio_Projeto_Livre_Gestao_Projetos.docx",apres:"files/Apresentacao_Oral_Projeto_Livre.pdf"}};</script>\n'
body = body.replace('<script src="data.js"></script>', shim + '<script src="data.js"></script>')
body = body.replace('Descarregar .pbix (em ZIP)', 'Descarregar .pbix')
html = ('<!doctype html><html lang="pt-PT"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        '<meta name="description" content="Dossiê interativo do Projeto Livre Power BI — Tema 3 Gestão de Projetos (dados fictícios)."><style>[hidden]{display:none!important}img{max-width:100%}</style></head><body>'
        + body + '</body></html>')
open(S + '/index.html', 'w').write(html)
print('site ok')
