"""Cria o guião da apresentação oral (5–8 min) em Word e PDF, pensado como fonte para o NotebookLM."""
import json, pickle, subprocess
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = '/home/user/projeto_livre'
R = pickle.load(open(f'{BASE}/scripts/analise.pkl', 'rb'))  # gerado localmente por analise.py
MOD = json.load(open(f'{BASE}/scripts/modelo.json', encoding='utf-8'))
T = R['tot']
NAVY, ORANGE, GREY = RGBColor(0x1D, 0x4E, 0x89), RGBColor(0xD9, 0x66, 0x1A), RGBColor(0x55, 0x5F, 0x6D)
pc = lambda v, d=1: f'{v * 100:.{d}f} %'.replace('.', ',')
sp = lambda v, d=1: ('+' if v >= 0 else '') + pc(v, d)
meur = lambda v: f'{v / 1e6:.1f} M€'.replace('.', ',')
n2 = lambda v, d=2: f'{v:.{d}f}'.replace('.', ',')
tipo, fase, gest, cat = R['tipo'], R['fase'], R['gestor'], R['cat']
reab, infra, f5, g1 = tipo.loc['Reabilitação'], tipo.loc['Infraestrutura'], fase.loc['F5'], gest.iloc[0]
nint = len(R['intervir']); g1n = int((R['intervir'].Gestor == gest.index[0]).sum())
k3 = cat.loc['K3']

doc = Document()
st = doc.styles['Normal']; st.font.name = 'Calibri'; st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
for s, size, color in (('Heading 1', 18, NAVY), ('Heading 2', 13.5, ORANGE), ('Heading 3', 11.5, NAVY)):
    doc.styles[s].font.size = Pt(size); doc.styles[s].font.color.rgb = color; doc.styles[s].font.name = 'Calibri'
sec = doc.sections[0]; sec.left_margin = sec.right_margin = Cm(2.2); sec.top_margin = sec.bottom_margin = Cm(2)


def p(text, bold=False, italic=False, color=None, size=None):
    par = doc.add_paragraph(); r = par.add_run(text); r.bold = bold; r.italic = italic
    if color: r.font.color.rgb = color
    if size: r.font.size = Pt(size)
    return par


def bl(items):
    for it in items:
        par = doc.add_paragraph(style='List Bullet')
        if isinstance(it, tuple):
            par.add_run(it[0]).bold = True; par.add_run(it[1])
        else:
            par.add_run(it)


def code(text):
    par = doc.add_paragraph(); r = par.add_run(text); r.font.name = 'Consolas'; r.font.size = Pt(9)
    r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Consolas')
    pPr = par._p.get_or_add_pPr(); sh = OxmlElement('w:shd'); sh.set(qn('w:val'), 'clear'); sh.set(qn('w:fill'), 'F2F4F7'); pPr.append(sh)


def slide(n, tempo, titulo, mostrar, pontos, fala):
    doc.add_heading(f'Diapositivo {n} — {titulo}', 2)
    p(f'Tempo: {tempo}  ·  No ecrã: {mostrar}', italic=True, color=GREY, size=10)
    p('Pontos-chave', bold=True, color=NAVY); bl(pontos)
    p('O que dizer', bold=True, color=NAVY)
    for f in fala:
        par = p(f); par.paragraph_format.left_indent = Cm(0.5)


# ---------- capa ----------
t = doc.add_paragraph(); r = t.add_run('Apresentação oral — Projeto Livre Power BI'); r.bold = True; r.font.size = Pt(24); r.font.color.rgb = NAVY
p('Tema 3 — Gestão de Projetos · Dashboard para o Diretor de Projetos da Vértice Construções (empresa fictícia)', bold=True, color=ORANGE, size=13)
p('Guião de 5 a 8 minutos: modelo de dados, duas medidas DAX, uma escolha de visualização e uma conclusão, como pede o guia do Projeto Livre (secção 6, ponto 3).', color=GREY)
doc.add_heading('Como usar este documento no NotebookLM', 3)
bl(['Carregar este PDF como fonte num caderno do NotebookLM (pode juntar também o relatório Word e o Guia_Projeto_Livre.pdf).',
    'Gerar um Resumo em Áudio ou em Vídeo com a instrução: "Apresentação de 6 minutos, em português de Portugal, para um formador de Power BI, seguindo a ordem dos diapositivos."',
    'Usar a secção "Perguntas prováveis do formador" para treinar a defesa no chat do NotebookLM.'])
doc.add_heading('Mensagem principal (uma frase)', 3)
p(f'A dashboard mostra ao Diretor de Projetos que o portefólio gasta {sp(T["desvio"])} acima do valor do trabalho feito, que a derrapagem se concentra nas obras de reabilitação e na fase de Instalações Técnicas, e diz em que {nint} projetos deve intervir primeiro.', bold=True)
doc.add_heading('Números-chave (31/12/2025, sem filtros)', 3)
tb = doc.add_table(rows=1, cols=2); tb.style = 'Light Grid Accent 1'
tb.rows[0].cells[0].text = 'Indicador'; tb.rows[0].cells[1].text = 'Valor'
for a, b in [('Projetos', '32 (16 concluídos, 15 em curso, 1 suspenso)'), ('Projetos atrasados', f'{int(T["atrasados"])} ({pc(T["atrasados"] / 32, 0)})'),
             ('Custo real acumulado', meur(T['AC'])), ('Valor ganho (EV)', meur(T['EV'])), ('Desvio de custo', sp(T['desvio'])),
             ('CPI · SPI', f'{n2(T["CPI"])} · {n2(T["SPI"])}'), ('Projetos a intervir', str(nint)), ('Medidas DAX', str(len(MOD['measures'])))]:
    c = tb.add_row().cells; c[0].text = a; c[1].text = b
doc.add_page_break()

# ---------- diapositivos ----------
doc.add_heading('Guião, diapositivo a diapositivo', 1)
slide(1, '0:00 – 0:45', 'O problema e quem usa a dashboard', 'Página 1 do Power BI (Visão Geral)',
      ['Utilizador: Diretor de Projetos / gestor de portefólio', 'Empresa fictícia com 32 obras em 2024–2025', 'Três perguntas: que projetos estão atrasados e exigem intervenção, onde estão os desvios, como se compara o progresso previsto com o real'],
      ['Bom dia. O meu projeto é sobre gestão de projetos numa empresa de construção, a Vértice Construções, que é fictícia.',
       'Quem vai usar a dashboard é o Diretor de Projetos. Ele acompanha 32 obras e precisa de decidir, na reunião mensal, em que projetos intervir primeiro.',
       'Por isso escolhi três perguntas: que projetos estão atrasados e exigem intervenção, onde estão os maiores desvios orçamentais e se o progresso real acompanha o previsto.'])
slide(2, '0:45 – 1:30', 'Os dados e o Power Query', 'Power Query Editor (consultas fCustos e dProjetos)',
      ['Dataset fictício em Excel, gerado com IA e indicado como tal', 'Erros propositados: duplicados, nulos, espaços, maiúsculas, textos diferentes',
       'Append dos custos de 2024 e 2025; Merge de clientes e gestores em dProjetos', 'Colunas novas: Dias_Atraso (personalizada) e Situacao_Prazo (condicional)'],
      ['Os dados são fictícios e isso está indicado no Excel e no relatório. Cobrem 24 meses, com quase 6 mil movimentos de custo e 635 tarefas.',
       'No Power Query fiz a limpeza: Trim e Capitalize Each Word, Replace Values, remover duplicados e nulos.',
       'Usei Append para juntar os custos de 2024 e 2025 e Merge para trazer o cliente e o gestor para a tabela de projetos.',
       'Criei a coluna Dias_Atraso, que compara o fim real, ou a data de corte, com o fim previsto.'])
slide(3, '1:30 – 2:45', 'O modelo de dados em estrela', 'Vista de Modelo do Power BI',
      ['4 factos: fCustos, fOrcamento, fTarefas, fProgresso', '4 dimensões: dProjetos, dFases, dCategorias, dCalendario',
       '15 relações Many-to-One, filtro numa só direção', 'dCalendario criada em DAX e marcada como tabela de datas', 'Relação inativa: fTarefas[Data_Fim_Real], usada com USERELATIONSHIP',
       'dProjetos não liga ao Calendário, para evitar caminhos ambíguos'],
      ['O modelo é uma estrela com quatro tabelas de factos e quatro dimensões partilhadas.',
       'Todas as relações são de muitos para um e o filtro vai sempre da dimensão para o facto. Assim, um segmentador de tipo de projeto filtra os quatro factos ao mesmo tempo.',
       'Os factos nunca estão ligados entre si. Comparo orçamento com custo real através das dimensões comuns.',
       'A tabela Calendário foi criada em DAX, com anos completos, e marcada como tabela de datas.',
       'As tarefas têm duas datas: a prevista é a relação ativa e a real fica inativa, a tracejado. Ativo-a numa medida com USERELATIONSHIP.',
       'Não liguei a tabela de projetos ao Calendário de propósito: isso criaria dois caminhos até cada facto, o que é ambíguo.'])
doc.add_picture(f'{BASE}/Modelo_Dados_Estrela.png', width=Cm(16))
ev = [m for m in MOD['measures'] if m[1] == 'Valor Ganho (EV)'][0][2]
pi = [m for m in MOD['measures'] if m[1] == 'Projetos Intervenção Prioritária'][0][2]
slide(4, '2:45 – 3:45', 'Medida DAX 1 — Valor Ganho (EV)', 'A medida no Power BI e o KPI Desvio de custo',
      [f'{len(MOD["measures"])} medidas explícitas na tabela _Medidas, em 6 pastas', 'fProgresso guarda valores acumulados no fim de cada mês: é semi-aditiva',
       'VAR UltimaData encontra a última fotografia do contexto; CALCULATE soma só essa data', f'Desvio de custo = custo real acumulado ÷ EV − 1 = {sp(T["desvio"])}'],
      ['Criei 42 medidas, todas numa tabela de medidas. Vou explicar duas.',
       'A primeira é o Valor Ganho. A tabela de progresso tem, para cada mês, o valor acumulado do trabalho feito. Se eu somasse todos os meses, contava o mesmo trabalho várias vezes.',
       'Por isso guardo numa variável a última data do contexto e o CALCULATE soma só essa fotografia. Se eu escolher 2024 no segmentador, a medida devolve o valor a 31 de dezembro de 2024.',
       'Com o Valor Ganho comparo o custo real com o valor do trabalho que foi feito, e não com o orçamento previsto. Um projeto atrasado gasta menos do que o plano e, na comparação simples, parecia estar a poupar.'])
code('Valor Ganho (EV) =\n' + ev)
slide(5, '3:45 – 4:45', 'Medida DAX 2 — Projetos Intervenção Prioritária', 'KPI Projetos a intervir e tabela com semáforo',
      ['FILTER percorre os projetos um a um', 'Dentro do FILTER, [Desvio de Custo %] e [SPI] são calculadas para cada projeto (transição de contexto)',
       'Critério: não concluído e (desvio > 10 % ou atraso > 30 dias ou SPI < 0,90)', f'Resultado: {nint} projetos'],
      ['A segunda medida transforma a análise numa decisão: quantos projetos exigem intervenção.',
       'O FILTER percorre a tabela de projetos. Para cada linha, as medidas de desvio e de SPI são calculadas só para esse projeto, o que se chama transição de contexto.',
       f'Conto os projetos ainda não concluídos que cumprem pelo menos um critério. Hoje são {nint}, e a tabela da página 1 mostra-os ordenados pelo desvio.'])
code('Projetos Intervenção Prioritária =\n' + pi)
slide(6, '4:45 – 5:30', 'Uma escolha de visualização', 'Página 1: tabela com semáforo · Página 2: dispersão atraso × desvio',
      ['Tabela com semáforo (verde, amarelo, vermelho) através de medidas de cor', 'Dispersão: atraso no eixo X, desvio no eixo Y, tamanho = orçamento',
       'Alternativas rejeitadas: gauges e gráficos circulares'],
      ['Para a lista de intervenção escolhi uma tabela com semáforo, em vez de gauges. O diretor vê logo a vermelho o que exige decisão.',
       'Na página 2 usei um gráfico de dispersão: num só visual vejo os projetos que têm os dois problemas, atraso e derrapagem, no canto superior direito.',
       'Evitei gráficos circulares: com quatro a sete categorias, as barras ordenadas comparam melhor.'])
slide(7, '5:30 – 6:45', 'Conclusão e recomendações', 'Página 2 com o filtro Fase = Instalações Técnicas',
      [f'Reabilitação: desvio {sp(reab["Desvio%"])} e SPI {n2(reab["SPI"])} (infraestrutura: {sp(infra["Desvio%"])})',
       f'Instalações Técnicas: {sp(f5["Desvio%"])} de desvio e {pc(f5["%Alto"], 0)} de tarefas de risco alto',
       f'{gest.index[0]}: {sp(g1["Desvio%"])} e {g1n} dos {nint} projetos a intervir', f'Subempreitadas: {sp(k3["Desvio_vs_plano%"])} face ao plano',
       'Recomendação 1: preço fechado nas subempreitadas de Instalações Técnicas e ponto de controlo de custos', 'Recomendação 2: reunião quinzenal dos projetos a intervir, apoio ao gestor, contingência de 15–20 % em reabilitação'],
      [f'A principal conclusão é que a derrapagem está concentrada. As obras de reabilitação estão {sp(reab["Desvio%"])} acima do valor ganho e a fase de Instalações Técnicas está {sp(f5["Desvio%"])}.',
       'Quando filtro essa fase, vejo que as subempreitadas são a categoria com maior desvio.',
       'Por isso recomendo duas coisas: contratar as subempreitadas desta fase com preço fechado, com um ponto de controlo de custos, e fazer uma reunião quinzenal sobre os projetos a intervir.',
       f'O risco é claro: com um CPI de {n2(T["CPI"])}, as obras em curso vão terminar cerca de {pc(1 / T["CPI"] - 1, 0)} acima do orçamento se nada mudar.'])
slide(8, '6:45 – 7:30', 'Validação e fecho', 'Folha Validacao do Excel ao lado do KPI no Power BI',
      ['Totais esperados calculados fora do Power BI (folha Validacao)', 'Teste dos segmentadores: Tipo = Reabilitação → +28,7 % (confirmado)', 'Uso de IA registado no Anexo B'],
      ['Validei os cálculos com a folha Validacao do Excel, que tem os totais esperados depois da limpeza. Testei os segmentadores: com Tipo igual a Reabilitação, o desvio dá 28,7 %, como previsto.',
       'Usei IA para gerar o dataset e acelerar a construção. O que alterei e o que fiz sozinho está no Anexo B.',
       'Em resumo, a dashboard diz ao Diretor de Projetos onde está o problema, porquê, e por onde começar. Obrigado.'])

# ---------- perguntas ----------
doc.add_page_break()
doc.add_heading('Perguntas prováveis do formador (e respostas curtas)', 1)
QA = [
    ('Porque é que o modelo é em estrela e não uma tabela única?', 'Porque tenho factos com granularidades diferentes: orçamento mensal, custos diários, tarefas e fotografias de progresso. Numa tabela única repetiria valores e as somas ficariam erradas.'),
    ('Porque não ligou dProjetos ao Calendário?', 'Porque os factos já ligam ao Calendário. Uma segunda ligação via dProjetos criaria dois caminhos do Calendário até cada facto, o que é uma relação ambígua.'),
    ('O que faz o USERELATIONSHIP?', 'Ativa, só dentro de uma medida, a relação inativa entre fTarefas[Data_Fim_Real] e o Calendário. Uso-o para contar tarefas pela data em que terminaram de facto.'),
    ('Qual a diferença entre "Desvio vs Orçamento %" e "Desvio de Custo %"?', 'O primeiro compara o custo real com o orçamento previsto até à data. O segundo compara com o valor do trabalho feito (EV). Num projeto atrasado o primeiro engana, porque gasta-se menos do que o previsto.'),
    ('O que são CPI e SPI?', 'CPI = valor ganho ÷ custo real (abaixo de 1 = gastou mais do que devia). SPI = valor ganho ÷ valor planeado (abaixo de 1 = está atrasado).'),
    ('Como garantiu que os números estão certos?', 'Comparei as medidas sem filtros com a folha Validacao do Excel, calculada fora do Power BI, e testei os segmentadores com casos conhecidos.'),
    ('Que limpeza fez no Power Query?', 'Trim e Capitalize Each Word nos textos, Replace Values nos estados, remover duplicados e nulos, Append de dois ficheiros, Merge de clientes e gestores e colunas personalizadas e condicionais.'),
    ('Porque é que os dados são fictícios?', 'Os datasets públicos não juntam orçamento, custos, tarefas e progresso dos mesmos projetos. O guia permite dados fictícios desde que sejam indicados, e estão indicados.'),
    ('O que faria a seguir?', 'Ligar a dados reais de obra, acrescentar uma previsão do custo final por projeto (EAC) e uma página de detalhe por projeto com drill-through.'),
]
for q, a in QA:
    p(q, bold=True, color=NAVY); p(a)

doc.add_heading('Dicas para a apresentação', 2)
bl(['Abrir já o .pbix na página 1, com os filtros limpos.', 'Ter a Vista de Modelo e a medida Valor Ganho (EV) prontas a mostrar.', 'Falar para o Diretor de Projetos: decisões, não gráficos.', 'Terminar dentro dos 8 minutos e deixar tempo para perguntas.'])

out = f'{BASE}/Apresentacao_Oral_Projeto_Livre.docx'
doc.save(out)
subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', '--outdir', BASE, out], check=True, capture_output=True)
print('ok')
