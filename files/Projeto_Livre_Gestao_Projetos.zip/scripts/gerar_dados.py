"""Gera o conjunto de dados fictício (Tema 3 — Gestão de Projetos) para o Projeto Livre Power BI.

Os dados são sintéticos (gerados por script, semente fixa) e incluem, de propósito, alguns problemas
de qualidade (espaços, maiúsculas/minúsculas, duplicados, nulos) para serem tratados no Power Query.
Saída: pickle com as tabelas limpas e "sujas" usado por criar_excel.py.
"""
import pickle, random
from datetime import date, timedelta
import numpy as np
import pandas as pd

SEED = 2025
random.seed(SEED); rng = np.random.default_rng(SEED)
CORTE = date(2025, 12, 31)          # data de corte da análise

# ---------------- dimensões ----------------
gestores = pd.DataFrame([
    ('G01', 'Ana Ribeiro', 'Edificação', 14), ('G02', 'Bruno Matos', 'Edificação', 9),
    ('G03', 'Carla Nunes', 'Infraestruturas', 17), ('G04', 'Diogo Ferreira', 'Reabilitação', 4),
    ('G05', 'Elisa Costa', 'Reabilitação', 11), ('G06', 'Filipe Santos', 'Infraestruturas', 7),
], columns=['ID_Gestor', 'Gestor', 'Departamento', 'Anos_Experiencia'])
# efeito do gestor no desvio de custo e no atraso
EF_GESTOR = {'G01': (0.00, 0.02), 'G02': (0.03, 0.05), 'G03': (-0.02, 0.03), 'G04': (0.09, 0.18),
             'G05': (0.04, 0.08), 'G06': (0.01, 0.06)}

clientes = pd.DataFrame([
    ('C01', 'Imobiliária Tejo Norte', 'Privado'), ('C02', 'Habitar Mais Promoção', 'Privado'),
    ('C03', 'Grupo Atlântico Retalho', 'Privado'), ('C04', 'Entidade Pública Regional Centro', 'Público'),
    ('C05', 'Fundo Património Histórico', 'Público'), ('C06', 'Logística Ibérica', 'Privado'),
    ('C07', 'Agrupamento Escolar do Norte', 'Público'), ('C08', 'Hotelaria Douro Vale', 'Privado'),
    ('C09', 'Infraestruturas Rodoviárias Sul', 'Público'), ('C10', 'Residências Universitárias Lis', 'Público'),
], columns=['ID_Cliente', 'Cliente', 'Setor'])

fases = pd.DataFrame([
    ('F1', 'Projeto e Licenciamento', 1, 0.06, 0.00, 0.16),
    ('F2', 'Estaleiro e Fundações', 2, 0.12, 0.10, 0.30),
    ('F3', 'Estrutura', 3, 0.25, 0.25, 0.55),
    ('F4', 'Alvenarias e Coberturas', 4, 0.14, 0.45, 0.70),
    ('F5', 'Instalações Técnicas', 5, 0.18, 0.55, 0.86),
    ('F6', 'Acabamentos', 6, 0.18, 0.70, 0.95),
    ('F7', 'Arranjos Exteriores e Entrega', 7, 0.07, 0.88, 1.00),
], columns=['ID_Fase', 'Fase', 'Ordem', 'Peso', 'Ini', 'Fim'])
# desvio de custo e de prazo extra por fase (Instalações Técnicas é a fase crítica)
EF_FASE = {'F1': (0.00, 0.04), 'F2': (0.04, 0.02), 'F3': (0.02, 0.00), 'F4': (0.01, 0.00),
           'F5': (0.13, 0.22), 'F6': (0.05, 0.03), 'F7': (0.00, 0.00)}

categorias = pd.DataFrame([
    ('K1', 'Mão de Obra'), ('K2', 'Materiais'), ('K3', 'Subempreitadas'), ('K4', 'Equipamentos'),
    ('K5', 'Custos Indiretos')], columns=['ID_Categoria', 'Categoria'])
EF_CAT = {'K1': 0.03, 'K2': 0.05, 'K3': 0.10, 'K4': -0.02, 'K5': 0.00}
SPLIT = {  # repartição do orçamento de cada fase por categoria
    'F1': {'K1': .55, 'K3': .30, 'K5': .15}, 'F2': {'K1': .25, 'K2': .30, 'K3': .15, 'K4': .25, 'K5': .05},
    'F3': {'K1': .30, 'K2': .45, 'K4': .20, 'K5': .05}, 'F4': {'K1': .35, 'K2': .45, 'K3': .15, 'K5': .05},
    'F5': {'K1': .15, 'K2': .25, 'K3': .55, 'K5': .05}, 'F6': {'K1': .35, 'K2': .40, 'K3': .20, 'K5': .05},
    'F7': {'K1': .30, 'K2': .25, 'K3': .30, 'K4': .10, 'K5': .05}}

TIPOS = {  # duração prevista (meses), orçamento (M€), efeito custo, efeito prazo
    'Residencial': ((10, 16), (1.2, 6.0), 0.02, 0.06),
    'Comercial': ((8, 14), (1.5, 8.0), 0.00, 0.04),
    'Infraestrutura': ((12, 20), (2.5, 12.0), -0.01, 0.10),
    'Reabilitação': ((6, 12), (0.4, 2.5), 0.15, 0.20),
}
PROJ = [
    ('Edifício Residencial Alvalade', 'Residencial', 'Lisboa', 'C01', 'G01'),
    ('Condomínio Jardins da Foz', 'Residencial', 'Porto', 'C02', 'G02'),
    ('Torre Habitacional Parque Nascente', 'Residencial', 'Porto', 'C02', 'G01'),
    ('Moradias Quinta do Lago Azul', 'Residencial', 'Faro', 'C01', 'G02'),
    ('Residência Universitária Campus Norte', 'Residencial', 'Braga', 'C10', 'G01'),
    ('Edifício Habitacional Benfica', 'Residencial', 'Lisboa', 'C01', 'G05'),
    ('Loteamento Vale Verde', 'Residencial', 'Setúbal', 'C02', 'G02'),
    ('Centro Comercial Matosinhos Sul', 'Comercial', 'Porto', 'C03', 'G02'),
    ('Retail Park Leiria', 'Comercial', 'Leiria', 'C03', 'G01'),
    ('Hotel Douro Vale', 'Comercial', 'Vila Real', 'C08', 'G05'),
    ('Escritórios Avenida da Liberdade', 'Comercial', 'Lisboa', 'C01', 'G01'),
    ('Armazém Logístico Azambuja', 'Comercial', 'Lisboa', 'C06', 'G06'),
    ('Plataforma Logística Carregado', 'Comercial', 'Lisboa', 'C06', 'G03'),
    ('Hotel Baixa Pombalina', 'Comercial', 'Lisboa', 'C08', 'G04'),
    ('Variante Rodoviária de Viseu', 'Infraestrutura', 'Viseu', 'C09', 'G03'),
    ('Ponte Pedonal do Mondego', 'Infraestrutura', 'Coimbra', 'C04', 'G03'),
    ('ETAR Intermunicipal Centro', 'Infraestrutura', 'Coimbra', 'C04', 'G06'),
    ('Escola Básica Nova Geração', 'Infraestrutura', 'Braga', 'C07', 'G06'),
    ('Pavilhão Desportivo Municipal', 'Infraestrutura', 'Aveiro', 'C04', 'G03'),
    ('Requalificação Avenida Marginal', 'Infraestrutura', 'Faro', 'C09', 'G06'),
    ('Parque de Estacionamento Central', 'Infraestrutura', 'Aveiro', 'C04', 'G03'),
    ('Reabilitação Palacete da Graça', 'Reabilitação', 'Lisboa', 'C05', 'G04'),
    ('Reabilitação Mercado Municipal', 'Reabilitação', 'Évora', 'C05', 'G05'),
    ('Reabilitação Edifício Baixa do Porto', 'Reabilitação', 'Porto', 'C01', 'G04'),
    ('Recuperação Convento de São Bento', 'Reabilitação', 'Évora', 'C05', 'G05'),
    ('Reabilitação Escola Secundária Sé', 'Reabilitação', 'Viseu', 'C07', 'G04'),
    ('Reabilitação Quarteirão Mouraria', 'Reabilitação', 'Lisboa', 'C05', 'G05'),
    ('Reconversão Fábrica de Lanifícios', 'Reabilitação', 'Castelo Branco', 'C02', 'G04'),
    ('Reabilitação Teatro Municipal', 'Reabilitação', 'Leiria', 'C04', 'G05'),
    ('Ampliação Hospital Privado Lis', 'Comercial', 'Leiria', 'C08', 'G02'),
    ('Residências Sénior Ria Formosa', 'Residencial', 'Faro', 'C02', 'G05'),
    ('Centro Escolar Ribeira', 'Infraestrutura', 'Vila Real', 'C07', 'G06'),
]

TAREFAS = {
    'F1': ['Projeto de execução', 'Licenciamento camarário', 'Revisão de projeto'],
    'F2': ['Montagem de estaleiro', 'Escavação e contenção', 'Fundações diretas', 'Fundações indiretas'],
    'F3': ['Betonagem de pilares', 'Lajes e vigas', 'Estrutura metálica', 'Impermeabilização de caves'],
    'F4': ['Alvenarias exteriores', 'Alvenarias interiores', 'Cobertura', 'Caixilharia exterior'],
    'F5': ['Rede elétrica', 'AVAC', 'Águas e esgotos', 'Rede de gás', 'Telecomunicações (ITED)'],
    'F6': ['Revestimentos de pavimentos', 'Pinturas', 'Carpintarias', 'Louças e equipamentos'],
    'F7': ['Arranjos exteriores', 'Limpezas finais', 'Vistoria e receção provisória'],
}
RESP = ['João Pires', 'Marta Lopes', 'Rui Carvalho', 'Sofia Almeida', 'Tiago Rocha', 'Inês Moreira',
        'Pedro Gaspar', 'Rita Fonseca', 'Hugo Teixeira', 'Catarina Dias']


def add_months(d, m):
    return d + timedelta(days=int(round(m * 30.44)))


def month_starts(a, b):
    d = date(a.year, a.month, 1)
    while d <= b:
        yield d
        d = date(d.year + (d.month == 12), d.month % 12 + 1, 1)


def overlap_days(a0, a1, b0, b1):
    s, e = max(a0, b0), min(a1, b1)
    return max(0, (e - s).days + 1)


projetos, orc, custos, tarefas, progresso = [], [], [], [], []
mov = 0; tid = 0
suspenso = 'P27'
for i, (nome, tipo, distrito, cli, ges) in enumerate(PROJ, 1):
    pid = f'P{i:02d}'
    (d0, d1), (o0, o1), ec_t, ep_t = TIPOS[tipo]
    dur = int(rng.integers(d0, d1 + 1))
    ini = date(2024, 1, 8) + timedelta(days=int(rng.integers(0, 540)))
    fim_prev = add_months(ini, dur)
    budget = round(float(rng.uniform(o0, o1)) * 1e6, -3)
    ec_g, ep_g = EF_GESTOR[ges]
    proj_cost = ec_t + ec_g + float(rng.normal(0, 0.04))
    proj_delay = max(-0.06, ep_t + ep_g - 0.08 + float(rng.normal(0, 0.05)))
    total_days = (fim_prev - ini).days
    corte_proj = CORTE
    if pid == suspenso:
        corte_proj = min(CORTE, ini + timedelta(days=int(total_days * 0.45)))
    plan_win, real_win = {}, {}
    for f in fases.itertuples():
        p0 = ini + timedelta(days=int(total_days * f.Ini)); p1 = ini + timedelta(days=int(total_days * f.Fim))
        dl = proj_delay + EF_FASE[f.ID_Fase][1] + float(rng.normal(0, 0.03))
        r0 = ini + timedelta(days=int(total_days * f.Ini * (1 + proj_delay)))
        r1 = r0 + timedelta(days=int((p1 - p0).days * (1 + max(-0.1, dl))))
        plan_win[f.ID_Fase] = (p0, p1); real_win[f.ID_Fase] = (r0, r1)
    fim_real_calc = max(w[1] for w in real_win.values())
    estado = 'Concluído' if fim_real_calc <= CORTE else 'Em curso'
    if pid == suspenso:
        estado = 'Suspenso'
    fim_real = fim_real_calc if estado == 'Concluído' else None
    prioridade = rng.choice(['Alta', 'Média', 'Baixa'], p=[.35, .45, .2])
    projetos.append(dict(ID_Projeto=pid, Projeto=nome, Tipo_Projeto=tipo, Distrito=distrito, ID_Cliente=cli,
                         ID_Gestor=ges, Data_Inicio=ini, Data_Fim_Prevista=fim_prev, Data_Fim_Real=fim_real,
                         Orcamento_Contratado=budget, Estado=estado, Prioridade=str(prioridade)))
    # orçamento mensal por fase e categoria (plano)
    plan_cum = {}; real_cum = {}
    for f in fases.itertuples():
        fb = budget * f.Peso
        p0, p1 = plan_win[f.ID_Fase]; r0, r1 = real_win[f.ID_Fase]
        pd_, rd_ = (p1 - p0).days + 1, (r1 - r0).days + 1
        for k, w in SPLIT[f.ID_Fase].items():
            v = fb * w
            for m in month_starts(p0, p1):
                me = date(m.year + (m.month == 12), m.month % 12 + 1, 1) - timedelta(days=1)
                part = v * overlap_days(m, me, p0, p1) / pd_
                if part > 0:
                    orc.append(dict(Data=m, ID_Projeto=pid, ID_Fase=f.ID_Fase, ID_Categoria=k, Valor_Orcamentado=round(part, 2)))
            fac = 1 + proj_cost + EF_FASE[f.ID_Fase][0] + EF_CAT[k] + float(rng.normal(0, 0.03))
            for m in month_starts(r0, min(r1, corte_proj)):
                me = date(m.year + (m.month == 12), m.month % 12 + 1, 1) - timedelta(days=1)
                a, b = max(m, r0), min(me, r1, corte_proj)
                if b < a:
                    continue
                part = v * fac * ((b - a).days + 1) / rd_
                n = int(rng.integers(1, 4))
                shares = rng.dirichlet(np.ones(n))
                for s in shares:
                    dd = a + timedelta(days=int(rng.integers(0, (b - a).days + 1)))
                    mov += 1
                    custos.append(dict(ID_Movimento=f'M{mov:06d}', Data=dd, ID_Projeto=pid, ID_Fase=f.ID_Fase,
                                       ID_Categoria=k, Valor=round(part * s, 2),
                                       Fornecedor_Tipo=rng.choice(['Interno', 'Fornecedor', 'Subempreiteiro']) if k != 'K1' else 'Interno'))
    # progresso mensal (fim de mês) por fase, em valor: planeado acumulado (PV) e ganho acumulado (EV)
    for m in month_starts(ini, CORTE):
        me = date(m.year + (m.month == 12), m.month % 12 + 1, 1) - timedelta(days=1)
        snap = min(me, CORTE)
        for f in fases.itertuples():
            p0, p1 = plan_win[f.ID_Fase]; r0, r1 = real_win[f.ID_Fase]
            fb = budget * f.Peso
            pv = fb * overlap_days(p0, snap, p0, p1) / ((p1 - p0).days + 1)
            ev = fb * overlap_days(r0, min(snap, corte_proj), r0, r1) / ((r1 - r0).days + 1)
            progresso.append(dict(Data=snap, ID_Projeto=pid, ID_Fase=f.ID_Fase,
                                  Valor_Planeado_Acum=round(pv, 2), Valor_Ganho_Acum=round(ev, 2)))
    # tarefas
    for f in fases.itertuples():
        nomes = TAREFAS[f.ID_Fase][:]
        random.shuffle(nomes)
        nt = int(rng.integers(2, min(4, len(nomes)) + 1))
        p0, p1 = plan_win[f.ID_Fase]; r0, r1 = real_win[f.ID_Fase]
        for j in range(nt):
            tid += 1
            a = p0 + timedelta(days=int((p1 - p0).days * j / nt * 0.8))
            b = a + timedelta(days=max(5, int((p1 - p0).days / nt * 1.25)))
            fac = (r1 - r0).days / max(1, (p1 - p0).days)
            ra = r0 + timedelta(days=int((a - p0).days * fac + rng.integers(-3, 6)))
            rb = ra + timedelta(days=max(4, int((b - a).days * fac * float(rng.uniform(0.92, 1.12)))))
            limite = corte_proj
            if rb <= limite:
                est, fr, prog = 'Concluída', rb, 1.0
            elif ra <= limite:
                est, fr = ('Bloqueada' if (pid == suspenso or rng.random() < .10) else 'Em curso'), None
                prog = round(min(.95, (limite - ra).days / max(1, (rb - ra).days)), 2)
            else:
                est, fr, prog, ra = 'Por iniciar', None, 0.0, None
            hp = int((b - a).days * float(rng.uniform(5, 14)))
            hr = int(hp * prog * float(rng.uniform(.95, 1.30)) * (1.15 if f.ID_Fase == 'F5' else 1)) if prog else 0
            atraso = ((fr or max(limite, b)) - b).days if est != 'Por iniciar' else max(0, (limite - b).days)
            risco = 'Alto' if (atraso > 45 or est == 'Bloqueada') else ('Médio' if atraso > 15 or f.ID_Fase == 'F5' else 'Baixo')
            tarefas.append(dict(ID_Tarefa=f'T{tid:04d}', ID_Projeto=pid, ID_Fase=f.ID_Fase, Tarefa=nomes[j],
                                Responsavel=random.choice(RESP), Data_Inicio_Prevista=a, Data_Fim_Prevista=b,
                                Data_Inicio_Real=ra, Data_Fim_Real=fr, Horas_Previstas=hp, Horas_Reais=hr,
                                Progresso=prog, Estado=est, Risco=risco))

dfp = pd.DataFrame(projetos); dfo = pd.DataFrame(orc); dfc = pd.DataFrame(custos)
dft = pd.DataFrame(tarefas); dfg = pd.DataFrame(progresso)
dfo = dfo.groupby(['Data', 'ID_Projeto', 'ID_Fase', 'ID_Categoria'], as_index=False)['Valor_Orcamentado'].sum().round(2)
# o orçamento da fase de projeto não tem custos de equipamento; garantir soma = contrato (arredondamentos)
clean = dict(projetos=dfp, clientes=clientes, gestores=gestores, fases=fases[['ID_Fase', 'Fase', 'Ordem']],
             categorias=categorias, orcamento=dfo, custos=dfc, tarefas=dft, progresso=dfg)

# ---------------- versão com problemas de qualidade ----------------
d = {k: v.copy() for k, v in clean.items()}
p = d['projetos']
p.loc[p.index % 5 == 1, 'Tipo_Projeto'] = p.loc[p.index % 5 == 1, 'Tipo_Projeto'].str.lower() + ' '
p.loc[p.index % 7 == 3, 'Distrito'] = '  ' + p.loc[p.index % 7 == 3, 'Distrito']
g = d['gestores']; g['Gestor'] = g['Gestor'].map(lambda s: s.upper() if s.startswith('D') else s + '  ')
c = d['custos']
c['Categoria_txt'] = None
c = c.sort_values(['Data', 'ID_Movimento']).reset_index(drop=True)
dup = c.sample(42, random_state=1)                       # 42 linhas duplicadas
nul = c.sample(15, random_state=2).copy(); nul['Valor'] = None; nul['ID_Movimento'] = [f'X{i:05d}' for i in range(15)]
semproj = c.sample(8, random_state=3).copy(); semproj['ID_Projeto'] = None; semproj['ID_Movimento'] = [f'Y{i:05d}' for i in range(8)]
c = pd.concat([c, dup, nul, semproj]).sort_values(['Data']).reset_index(drop=True)
mask = c.index % 37 == 0
c.loc[mask, 'Fornecedor_Tipo'] = c.loc[mask, 'Fornecedor_Tipo'].str.upper()
c = c.drop(columns='Categoria_txt')
d['custos'] = c
t = d['tarefas']
t.loc[t.index % 9 == 0, 'Estado'] = t.loc[t.index % 9 == 0, 'Estado'].replace({'Concluída': 'Concluida', 'Em curso': 'em curso'})
t.loc[t.index % 6 == 0, 'Responsavel'] = ' ' + t.loc[t.index % 6 == 0, 'Responsavel'] + ' '
t = pd.concat([t, t.sample(6, random_state=4)]).sort_values('ID_Tarefa').reset_index(drop=True)
d['tarefas'] = t

pickle.dump({'clean': clean, 'dirty': d, 'corte': CORTE}, open('/home/user/projeto_livre/scripts/dados.pkl', 'wb'))
for k, v in clean.items():
    print(k, len(v), '| sujo:', len(d[k]))
print('Orçamento total', dfo.Valor_Orcamentado.sum().round(0), 'Custo real', dfc.Valor.sum().round(0))
print(dfp.Estado.value_counts().to_dict())
