"""Cria o projeto Power BI (PBIP: modelo TMDL + relatório PBIR) ligado ao Excel Dados_Gestao_Projetos.xlsx."""
import json, os, shutil, uuid, secrets
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

BASE = '/home/user/projeto_livre'
NAME = 'Gestao_Projetos'
OUT = f'{BASE}/PowerBI'
SM = f'{OUT}/{NAME}.SemanticModel'
RP = f'{OUT}/{NAME}.Report'
EXCEL_PATH = r'C:\PowerBI\Projeto_Livre\Dados_Gestao_Projetos.xlsx'
FLUENT = '/home/user/pbix_work/orig/Report/StaticResources/SharedResources/BaseThemes/Fluent2-CY26SU10.json'

shutil.rmtree(OUT, ignore_errors=True)
for p in (f'{SM}/definition/tables', f'{RP}/definition/pages', f'{RP}/StaticResources/RegisteredResources',
          f'{RP}/StaticResources/SharedResources/BaseThemes'):
    os.makedirs(p)


def tag():
    return str(uuid.uuid4())


def w(path, text):
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(text)


def q(name):  # nome TMDL entre plicas quando necessário
    return name if name.replace('_', '').isalnum() and name.isascii() else "'" + name.replace("'", "''") + "'"


def indent(text, n):
    return '\n'.join(('\t' * n + l) if l.strip() else '' for l in text.strip('\n').split('\n'))


# =====================================================================
# 1. MODELO SEMÂNTICO (TMDL)
# =====================================================================
DT = {'text': 'string', 'date': 'dateTime', 'cur': 'decimal', 'int': 'int64', 'num': 'double'}
FMT = {'date': 'dd/mm/yyyy', 'cur': '#,0.00 €;-#,0.00 €;#,0.00 €', 'int': '0', 'num': '0.00'}
NAV = 'Origem = Excel.Workbook(File.Contents(Text.Trim(CaminhoExcel, {"""", " "})), null, true),'

TABLES = {}   # nome -> (colunas[(nome, tipo, extras)], M ou DAX, kind)

TABLES['dProjetos'] = ([
    ('ID_Projeto', 'text', {}), ('Projeto', 'text', {}), ('Tipo_Projeto', 'text', {}), ('Distrito', 'text', {'dataCategory': 'StateOrProvince'}),
    ('ID_Cliente', 'text', {'isHidden': True}), ('ID_Gestor', 'text', {'isHidden': True}), ('Data_Inicio', 'date', {}),
    ('Data_Fim_Prevista', 'date', {}), ('Data_Fim_Real', 'date', {}), ('Orcamento_Contratado', 'cur', {}), ('Estado', 'text', {}),
    ('Prioridade', 'text', {}), ('Cliente', 'text', {}), ('Setor', 'text', {}), ('Gestor', 'text', {}), ('Departamento', 'text', {}),
    ('Dias_Atraso', 'int', {}), ('Situacao_Prazo', 'text', {}), ('Duracao_Prevista_Meses', 'num', {})], f'''
let
    {NAV}
    Tabela = Origem{{[Item="tProjetos",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"ID_Projeto", type text}}, {{"Projeto", type text}}, {{"Tipo_Projeto", type text}}, {{"Distrito", type text}}, {{"ID_Cliente", type text}}, {{"ID_Gestor", type text}}, {{"Data_Inicio", type date}}, {{"Data_Fim_Prevista", type date}}, {{"Data_Fim_Real", type date}}, {{"Orcamento_Contratado", Currency.Type}}, {{"Estado", type text}}, {{"Prioridade", type text}}}}),
    LimparTexto = Table.TransformColumns(Tipos, {{{{"Projeto", Text.Trim, type text}}, {{"Tipo_Projeto", each Text.Proper(Text.Trim(_)), type text}}, {{"Distrito", each Text.Proper(Text.Trim(_)), type text}}}}),
    JuntarClientes = Table.NestedJoin(LimparTexto, {{"ID_Cliente"}}, stg_Clientes, {{"ID_Cliente"}}, "stg_Clientes", JoinKind.LeftOuter),
    ExpandirClientes = Table.ExpandTableColumn(JuntarClientes, "stg_Clientes", {{"Cliente", "Setor"}}, {{"Cliente", "Setor"}}),
    JuntarGestores = Table.NestedJoin(ExpandirClientes, {{"ID_Gestor"}}, stg_Gestores, {{"ID_Gestor"}}, "stg_Gestores", JoinKind.LeftOuter),
    ExpandirGestores = Table.ExpandTableColumn(JuntarGestores, "stg_Gestores", {{"Gestor", "Departamento"}}, {{"Gestor", "Departamento"}}),
    DiasAtraso = Table.AddColumn(ExpandirGestores, "Dias_Atraso", each if [Data_Fim_Real] <> null then Duration.Days([Data_Fim_Real] - [Data_Fim_Prevista]) else List.Max({{0, Duration.Days(DataCorte - [Data_Fim_Prevista])}}), Int64.Type),
    SituacaoPrazo = Table.AddColumn(DiasAtraso, "Situacao_Prazo", each if [Dias_Atraso] <= 0 then "No prazo" else if [Dias_Atraso] <= 30 then "Atraso ligeiro (até 30 dias)" else if [Dias_Atraso] <= 90 then "Atraso moderado (31 a 90 dias)" else "Atraso grave (mais de 90 dias)", type text),
    Duracao = Table.AddColumn(SituacaoPrazo, "Duracao_Prevista_Meses", each Number.Round(Duration.Days([Data_Fim_Prevista] - [Data_Inicio]) / 30.44, 1), type number)
in
    Duracao''', 'm')

TABLES['dFases'] = ([('ID_Fase', 'text', {}), ('Fase', 'text', {'sortByColumn': 'Ordem'}), ('Ordem', 'int', {'isHidden': True})], f'''
let
    {NAV}
    Tabela = Origem{{[Item="tFases",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"ID_Fase", type text}}, {{"Fase", type text}}, {{"Ordem", Int64.Type}}}})
in
    Tipos''', 'm')

TABLES['dCategorias'] = ([('ID_Categoria', 'text', {}), ('Categoria', 'text', {})], f'''
let
    {NAV}
    Tabela = Origem{{[Item="tCategorias",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"ID_Categoria", type text}}, {{"Categoria", type text}}}})
in
    Tipos''', 'm')

TABLES['fOrcamento'] = ([('Data', 'date', {}), ('ID_Projeto', 'text', {'isHidden': True}), ('ID_Fase', 'text', {'isHidden': True}),
                         ('ID_Categoria', 'text', {'isHidden': True}), ('Valor_Orcamentado', 'cur', {})], f'''
let
    {NAV}
    Tabela = Origem{{[Item="tOrcamento",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"Data", type date}}, {{"ID_Projeto", type text}}, {{"ID_Fase", type text}}, {{"ID_Categoria", type text}}, {{"Valor_Orcamentado", Currency.Type}}}})
in
    Tipos''', 'm')

TABLES['fCustos'] = ([('ID_Movimento', 'text', {}), ('Data', 'date', {}), ('ID_Projeto', 'text', {'isHidden': True}), ('ID_Fase', 'text', {'isHidden': True}),
                      ('ID_Categoria', 'text', {'isHidden': True}), ('Valor', 'cur', {}), ('Fornecedor_Tipo', 'text', {}), ('Ano_Ficheiro', 'int', {})], f'''
let
    {NAV}
    Custos2024 = Table.AddColumn(Origem{{[Item="tCustos2024",Kind="Table"]}}[Data], "Ano_Ficheiro", each 2024, Int64.Type),
    Custos2025 = Table.AddColumn(Origem{{[Item="tCustos2025",Kind="Table"]}}[Data], "Ano_Ficheiro", each 2025, Int64.Type),
    JuntarAnos = Table.Combine({{Custos2024, Custos2025}}),
    Tipos = Table.TransformColumnTypes(JuntarAnos, {{{{"ID_Movimento", type text}}, {{"Data", type date}}, {{"ID_Projeto", type text}}, {{"ID_Fase", type text}}, {{"ID_Categoria", type text}}, {{"Valor", Currency.Type}}, {{"Fornecedor_Tipo", type text}}}}),
    LimparTexto = Table.TransformColumns(Tipos, {{{{"Fornecedor_Tipo", each Text.Proper(Text.Trim(_)), type text}}}}),
    RemoverDuplicados = Table.Distinct(LimparTexto),
    RemoverNulos = Table.SelectRows(RemoverDuplicados, each [Valor] <> null and [ID_Projeto] <> null)
in
    RemoverNulos''', 'm')

TABLES['fTarefas'] = ([('ID_Tarefa', 'text', {}), ('ID_Projeto', 'text', {'isHidden': True}), ('ID_Fase', 'text', {'isHidden': True}),
                       ('Tarefa', 'text', {}), ('Responsavel', 'text', {}), ('Data_Inicio_Prevista', 'date', {}), ('Data_Fim_Prevista', 'date', {}),
                       ('Data_Inicio_Real', 'date', {}), ('Data_Fim_Real', 'date', {}), ('Horas_Previstas', 'int', {}), ('Horas_Reais', 'int', {}),
                       ('Progresso', 'num', {'formatString': '0%'}), ('Estado', 'text', {}), ('Risco', 'text', {'sortByColumn': 'Risco_Ordem'}),
                       ('Dias_Atraso', 'int', {}), ('Atrasada', 'text', {}), ('Risco_Ordem', 'int', {'isHidden': True})], f'''
let
    {NAV}
    Tabela = Origem{{[Item="tTarefas",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"ID_Tarefa", type text}}, {{"ID_Projeto", type text}}, {{"ID_Fase", type text}}, {{"Tarefa", type text}}, {{"Responsavel", type text}}, {{"Data_Inicio_Prevista", type date}}, {{"Data_Fim_Prevista", type date}}, {{"Data_Inicio_Real", type date}}, {{"Data_Fim_Real", type date}}, {{"Horas_Previstas", Int64.Type}}, {{"Horas_Reais", Int64.Type}}, {{"Progresso", type number}}, {{"Estado", type text}}, {{"Risco", type text}}}}),
    LimparTexto = Table.TransformColumns(Tipos, {{{{"Responsavel", Text.Trim, type text}}, {{"Estado", Text.Trim, type text}}}}),
    CorrigirConcluida = Table.ReplaceValue(LimparTexto, "Concluida", "Concluída", Replacer.ReplaceValue, {{"Estado"}}),
    CorrigirEmCurso = Table.ReplaceValue(CorrigirConcluida, "em curso", "Em curso", Replacer.ReplaceValue, {{"Estado"}}),
    RemoverDuplicados = Table.Distinct(CorrigirEmCurso),
    DiasAtraso = Table.AddColumn(RemoverDuplicados, "Dias_Atraso", each if [Data_Fim_Real] <> null then Duration.Days([Data_Fim_Real] - [Data_Fim_Prevista]) else List.Max({{0, Duration.Days(DataCorte - [Data_Fim_Prevista])}}), Int64.Type),
    Atrasada = Table.AddColumn(DiasAtraso, "Atrasada", each if [Dias_Atraso] > 0 then "Sim" else "Não", type text),
    RiscoOrdem = Table.AddColumn(Atrasada, "Risco_Ordem", each if [Risco] = "Alto" then 1 else if [Risco] = "Médio" then 2 else 3, Int64.Type)
in
    RiscoOrdem''', 'm')

TABLES['fProgresso'] = ([('Data', 'date', {}), ('ID_Projeto', 'text', {'isHidden': True}), ('ID_Fase', 'text', {'isHidden': True}),
                         ('Valor_Planeado_Acum', 'cur', {}), ('Valor_Ganho_Acum', 'cur', {})], f'''
let
    {NAV}
    Tabela = Origem{{[Item="tProgresso",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"Data", type date}}, {{"ID_Projeto", type text}}, {{"ID_Fase", type text}}, {{"Valor_Planeado_Acum", Currency.Type}}, {{"Valor_Ganho_Acum", Currency.Type}}}})
in
    Tipos''', 'm')

CAL_COLS = [('Date', 'date', {'isKey': True}), ('Ano', 'int', {}), ('MesNumero', 'int', {'isHidden': True}),
            ('Mes', 'text', {'sortByColumn': 'MesNumero'}), ('MesAno', 'text', {'sortByColumn': 'AnoMes'}),
            ('Trimestre', 'text', {}), ('AnoMes', 'text', {}), ('AnoTrimestre', 'text', {})]
TABLES['dCalendario'] = (CAL_COLS, '''
ADDCOLUMNS(
    CALENDAR(
        DATE(YEAR(MIN(fOrcamento[Data])), 1, 1),
        DATE(YEAR(MAX(fOrcamento[Data])), 12, 31)
    ),
    "Ano", YEAR([Date]),
    "MesNumero", MONTH([Date]),
    "Mes", FORMAT([Date], "MMMM"),
    "MesAno", FORMAT([Date], "MMM yyyy"),
    "Trimestre", "T" & FORMAT([Date], "Q"),
    "AnoMes", FORMAT([Date], "yyyy-MM"),
    "AnoTrimestre", YEAR([Date]) & " T" & FORMAT([Date], "Q")
)''', 'dax')

# ---------------- medidas (_Medidas) ----------------
EUR = '#,0 €;-#,0 €;#,0 €'
PCT = '0.0%;-0.0%;0.0%'
M = [  # (pasta, nome, expressão, formato, descrição)
    ('1. Portefólio', 'Nº Projetos', 'COUNTROWS(dProjetos)', '0', 'Número de projetos no contexto de filtro.'),
    ('1. Portefólio', 'Projetos Concluídos', 'CALCULATE([Nº Projetos], dProjetos[Estado] = "Concluído")', '0', ''),
    ('1. Portefólio', 'Projetos em Curso', 'CALCULATE([Nº Projetos], dProjetos[Estado] = "Em curso")', '0', ''),
    ('1. Portefólio', 'Projetos Atrasados', 'CALCULATE([Nº Projetos], dProjetos[Dias_Atraso] > 0)', '0', 'Projetos concluídos depois do prazo ou ainda abertos com o prazo ultrapassado.'),
    ('1. Portefólio', '% Projetos Atrasados', 'DIVIDE([Projetos Atrasados], [Nº Projetos])', PCT, ''),
    ('1. Portefólio', 'Dias de Atraso', 'AVERAGE(dProjetos[Dias_Atraso])', '0', 'Dias de atraso (negativo = antecipado). Por projeto devolve o seu atraso.'),
    ('1. Portefólio', 'Dias de Atraso Médio', 'CALCULATE(AVERAGE(dProjetos[Dias_Atraso]), dProjetos[Dias_Atraso] > 0)', '0', 'Média de dias de atraso apenas dos projetos atrasados.'),
    ('2. Orçamento vs Real', 'Data de Corte', 'CALCULATE(MAX(fProgresso[Data]), REMOVEFILTERS())', 'dd/mm/yyyy', 'Última data com dados (31/12/2025).'),
    ('2. Orçamento vs Real', 'Orçamento Contratado', 'SUM(dProjetos[Orcamento_Contratado])', EUR, 'Valor contratado dos projetos (BAC).'),
    ('2. Orçamento vs Real', 'Orçamento Planeado', 'SUM(fOrcamento[Valor_Orcamentado])', EUR, 'Custo planeado no período filtrado.'),
    ('2. Orçamento vs Real', 'Orçamento Total (BAC)', 'CALCULATE([Orçamento Planeado], REMOVEFILTERS(dCalendario))', EUR, 'Orçamento total, independente das datas (respeita projeto, fase e categoria).'),
    ('2. Orçamento vs Real', 'Orçamento até à Data', 'VAR Corte = [Data de Corte]\nRETURN\n    CALCULATE([Orçamento Planeado], KEEPFILTERS(dCalendario[Date] <= Corte))', EUR, 'Orçamento planeado até à data de corte (exclui custos planeados para o futuro).'),
    ('2. Orçamento vs Real', 'Custo Real', 'SUM(fCustos[Valor])', EUR, 'Custos reais registados no período.'),
    ('2. Orçamento vs Real', 'Desvio vs Orçamento €', '[Custo Real] - [Orçamento até à Data]', EUR, 'Positivo = gastou-se mais do que o planeado para o período.'),
    ('2. Orçamento vs Real', 'Desvio vs Orçamento %', 'DIVIDE([Desvio vs Orçamento €], [Orçamento até à Data])', PCT, ''),
    ('2. Orçamento vs Real', '% Execução do Orçamento', 'DIVIDE([Custo Real], [Orçamento Total (BAC)])', PCT, 'Parte do orçamento total já consumida.'),
    ('3. Valor Ganho (EVM)', 'Valor Planeado (PV)', 'VAR UltimaData = MAX(fProgresso[Data])\nRETURN\n    CALCULATE(SUM(fProgresso[Valor_Planeado_Acum]), fProgresso[Data] = UltimaData)', EUR, 'Valor do trabalho que devia estar feito na última data do contexto (semi-aditivo).'),
    ('3. Valor Ganho (EVM)', 'Valor Ganho (EV)', 'VAR UltimaData = MAX(fProgresso[Data])\nRETURN\n    CALCULATE(SUM(fProgresso[Valor_Ganho_Acum]), fProgresso[Data] = UltimaData)', EUR, 'Valor orçamentado do trabalho efetivamente feito.'),
    ('3. Valor Ganho (EVM)', 'Custo Real Acumulado', 'VAR UltimaData = MAX(fProgresso[Data])\nRETURN\n    CALCULATE([Custo Real], REMOVEFILTERS(dCalendario), fCustos[Data] <= UltimaData)', EUR, 'Custo real desde o início até à última data do contexto (AC).'),
    ('3. Valor Ganho (EVM)', 'Desvio de Custo €', '[Custo Real Acumulado] - [Valor Ganho (EV)]', EUR, 'Quanto se gastou a mais pelo trabalho feito (positivo = derrapagem).'),
    ('3. Valor Ganho (EVM)', 'Desvio de Custo %', 'DIVIDE([Desvio de Custo €], [Valor Ganho (EV)])', PCT, 'Desvio orçamental em % do trabalho realizado.'),
    ('3. Valor Ganho (EVM)', 'CPI', 'DIVIDE([Valor Ganho (EV)], [Custo Real Acumulado])', '0.00', 'Índice de desempenho de custo (<1 = acima do orçamento).'),
    ('3. Valor Ganho (EVM)', 'SPI', 'DIVIDE([Valor Ganho (EV)], [Valor Planeado (PV)])', '0.00', 'Índice de desempenho de prazo (<1 = atrasado).'),
    ('3. Valor Ganho (EVM)', 'Progresso Previsto %', 'DIVIDE([Valor Planeado (PV)], [Orçamento Total (BAC)])', PCT, ''),
    ('3. Valor Ganho (EVM)', 'Progresso Real %', 'DIVIDE([Valor Ganho (EV)], [Orçamento Total (BAC)])', PCT, ''),
    ('3. Valor Ganho (EVM)', 'Desvio de Progresso (p.p.)', '[Progresso Real %] - [Progresso Previsto %]', PCT, 'Diferença em pontos percentuais entre progresso real e previsto.'),
    ('4. Inteligência Temporal', 'Custo Real Ano Anterior', 'CALCULATE([Custo Real], SAMEPERIODLASTYEAR(dCalendario[Date]))', EUR, ''),
    ('4. Inteligência Temporal', 'Variação Custo vs Ano Anterior %', 'DIVIDE([Custo Real] - [Custo Real Ano Anterior], [Custo Real Ano Anterior])', PCT, ''),
    ('4. Inteligência Temporal', 'Custo Real YTD', 'TOTALYTD([Custo Real], dCalendario[Date])', EUR, 'Custo real acumulado no ano.'),
    ('4. Inteligência Temporal', 'Orçamento YTD', 'TOTALYTD([Orçamento Planeado], dCalendario[Date])', EUR, 'Orçamento acumulado no ano.'),
    ('5. Tarefas', 'Nº Tarefas', 'COUNTROWS(fTarefas)', '0', ''),
    ('5. Tarefas', 'Tarefas Atrasadas', 'CALCULATE([Nº Tarefas], fTarefas[Dias_Atraso] > 0)', '0', ''),
    ('5. Tarefas', '% Tarefas Atrasadas', 'DIVIDE([Tarefas Atrasadas], [Nº Tarefas])', PCT, ''),
    ('5. Tarefas', 'Tarefas Alto Risco', 'CALCULATE([Nº Tarefas], fTarefas[Risco] = "Alto")', '0', ''),
    ('5. Tarefas', '% Tarefas Alto Risco', 'DIVIDE([Tarefas Alto Risco], [Nº Tarefas])', PCT, ''),
    ('5. Tarefas', 'Tarefas Concluídas (data real)', 'CALCULATE([Nº Tarefas], USERELATIONSHIP(fTarefas[Data_Fim_Real], dCalendario[Date]))', '0', 'Usa a relação inativa: conta as tarefas pela data em que terminaram de facto.'),
    ('5. Tarefas', 'Desvio de Horas %', 'VAR HorasReais = SUM(fTarefas[Horas_Reais])\nVAR HorasPrevistasFeitas = SUMX(fTarefas, fTarefas[Horas_Previstas] * fTarefas[Progresso])\nRETURN\n    DIVIDE(HorasReais - HorasPrevistasFeitas, HorasPrevistasFeitas)', PCT, 'Horas gastas face às horas previstas para o trabalho já feito.'),
    ('6. Intervenção', 'Projetos Intervenção Prioritária', 'COUNTROWS(\n    FILTER(\n        dProjetos,\n        dProjetos[Estado] <> "Concluído"\n            && ( [Desvio de Custo %] > 0.10 || dProjetos[Dias_Atraso] > 30 || [SPI] < 0.90 )\n    )\n)', '0', 'Projetos não concluídos com desvio de custo > 10%, atraso > 30 dias ou SPI < 0,90.'),
    ('6. Intervenção', 'Estado de Intervenção', 'IF(\n    HASONEVALUE(dProjetos[ID_Projeto]),\n    SWITCH(\n        TRUE(),\n        SELECTEDVALUE(dProjetos[Estado]) = "Concluído", "Concluído",\n        [Projetos Intervenção Prioritária] = 1, "Intervir",\n        [Desvio de Custo %] > 0.05 || [SPI] < 0.95, "Acompanhar",\n        "Normal"\n    )\n)', None, 'Classificação de cada projeto para a reunião de portefólio.'),
    ('6. Intervenção', 'Cor Desvio', 'SWITCH(TRUE(), [Desvio de Custo %] > 0.10, "#E5484D", [Desvio de Custo %] > 0.05, "#F5A524", "#30A46C")', None, 'Cor para formatação condicional (semáforo).'),
    ('6. Intervenção', 'Cor SPI', 'SWITCH(TRUE(), [SPI] < 0.90, "#E5484D", [SPI] < 0.97, "#F5A524", "#30A46C")', None, 'Cor para formatação condicional (semáforo).'),
    ('6. Intervenção', 'Cor Intervenção', 'SWITCH([Estado de Intervenção], "Intervir", "#E5484D", "Acompanhar", "#F5A524", "Normal", "#30A46C", "#9FB0C8")', None, ''),
]
N_MEDIDAS = len(M)


def col_tmdl(name, typ, ex, calc=False):
    out = [f'\tcolumn {q(name)}', f'\t\tdataType: {DT[typ]}']
    if ex.get('isKey'):
        out.append('\t\tisKey')
    if ex.get('isHidden'):
        out.append('\t\tisHidden')
    fs = ex.get('formatString', FMT.get(typ))
    if fs and typ != 'text':
        out.append(f'\t\tformatString: {fs}')
    if calc:
        out.append('\t\tisNameInferred')
    out.append(f'\t\tlineageTag: {tag()}')
    out.append(f'\t\tsummarizeBy: {"sum" if typ in ("cur", "num") and not calc else "none"}')
    if ex.get('dataCategory'):
        out.append(f'\t\tdataCategory: {ex["dataCategory"]}')
    out.append(f'\t\tsourceColumn: {"[" + name + "]" if calc else name}')
    if ex.get('sortByColumn'):
        out.append(f'\t\tsortByColumn: {ex["sortByColumn"]}')
    out.append('')
    out.append('\t\tannotation SummarizationSetBy = Automatic')
    if typ == 'date':
        out.append('')
        out.append('\t\tannotation UnderlyingDateTimeDataType = Date')
    return '\n'.join(out) + '\n'


for tname, (cols, src, kind) in TABLES.items():
    parts = [f'table {tname}', f'\tlineageTag: {tag()}']
    if tname == 'dCalendario':
        parts.append('\tdataCategory: Time')
    parts.append('')
    for c in cols:
        parts.append(col_tmdl(*c, calc=(kind == 'dax')))
    if kind == 'm':
        parts.append(f'\tpartition {tname} = m\n\t\tmode: import\n\t\tsource =\n{indent(src, 4)}\n')
    else:
        parts.append(f'\tpartition {tname} = calculated\n\t\tmode: import\n\t\tsource =\n{indent(src, 4)}\n')
    parts.append('\tannotation PBI_ResultType = Table\n')
    w(f'{SM}/definition/tables/{tname}.tmdl', '\n'.join(parts))

# tabela de medidas
mp = ['table _Medidas', f'\tlineageTag: {tag()}', '']
for folder, name, expr, fmt, desc in M:
    if desc:
        mp.append(f'\t/// {desc}')
    if '\n' in expr:
        mp.append(f'\tmeasure {q(name)} =\n{indent(expr, 3)}')
    else:
        mp.append(f'\tmeasure {q(name)} = {expr}')
    if fmt:
        mp.append(f'\t\tformatString: {fmt}')
    mp.append(f'\t\tdisplayFolder: {folder}')
    mp.append(f'\t\tlineageTag: {tag()}')
    mp.append('')
mp.append(f'''\tcolumn Ignorar
\t\tdataType: int64
\t\tisHidden
\t\tformatString: 0
\t\tisNameInferred
\t\tlineageTag: {tag()}
\t\tsummarizeBy: none
\t\tsourceColumn: [Ignorar]

\t\tannotation SummarizationSetBy = Automatic

\tpartition _Medidas = calculated
\t\tmode: import
\t\tsource = ROW("Ignorar", 0)

\tannotation PBI_ResultType = Table
''')
w(f'{SM}/definition/tables/_Medidas.tmdl', '\n'.join(mp))

# expressões partilhadas: parâmetros e consultas auxiliares (não carregadas no modelo)
expr = f'''expression CaminhoExcel = "{EXCEL_PATH}" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]
\tlineageTag: {tag()}

\tannotation PBI_ResultType = Text

expression DataCorte = #date(2025, 12, 31) meta [IsParameterQuery=true, Type="Date", IsParameterQueryRequired=true]
\tlineageTag: {tag()}

\tannotation PBI_ResultType = Date

expression stg_Clientes =
{indent(f"""
let
    {NAV}
    Tabela = Origem{{[Item="tClientes",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"ID_Cliente", type text}}, {{"Cliente", type text}}, {{"Setor", type text}}}}),
    LimparTexto = Table.TransformColumns(Tipos, {{{{"Cliente", Text.Trim, type text}}}})
in
    LimparTexto""", 2)}
\tlineageTag: {tag()}

\tannotation PBI_ResultType = Table

expression stg_Gestores =
{indent(f"""
let
    {NAV}
    Tabela = Origem{{[Item="tGestores",Kind="Table"]}}[Data],
    Tipos = Table.TransformColumnTypes(Tabela, {{{{"ID_Gestor", type text}}, {{"Gestor", type text}}, {{"Departamento", type text}}, {{"Anos_Experiencia", Int64.Type}}}}),
    LimparTexto = Table.TransformColumns(Tipos, {{{{"Gestor", each Text.Proper(Text.Trim(_)), type text}}}})
in
    LimparTexto""", 2)}
\tlineageTag: {tag()}

\tannotation PBI_ResultType = Table
'''
w(f'{SM}/definition/expressions.tmdl', expr)

RELS = [('fOrcamento', 'ID_Projeto', 'dProjetos', 'ID_Projeto'), ('fCustos', 'ID_Projeto', 'dProjetos', 'ID_Projeto'),
        ('fTarefas', 'ID_Projeto', 'dProjetos', 'ID_Projeto'), ('fProgresso', 'ID_Projeto', 'dProjetos', 'ID_Projeto'),
        ('fOrcamento', 'ID_Fase', 'dFases', 'ID_Fase'), ('fCustos', 'ID_Fase', 'dFases', 'ID_Fase'),
        ('fTarefas', 'ID_Fase', 'dFases', 'ID_Fase'), ('fProgresso', 'ID_Fase', 'dFases', 'ID_Fase'),
        ('fOrcamento', 'ID_Categoria', 'dCategorias', 'ID_Categoria'), ('fCustos', 'ID_Categoria', 'dCategorias', 'ID_Categoria'),
        ('fOrcamento', 'Data', 'dCalendario', 'Date'), ('fCustos', 'Data', 'dCalendario', 'Date'),
        ('fProgresso', 'Data', 'dCalendario', 'Date'), ('fTarefas', 'Data_Fim_Prevista', 'dCalendario', 'Date'),
        ('fTarefas', 'Data_Fim_Real', 'dCalendario', 'Date', False)]
rl = []
for r in RELS:
    f, fc, t, tc = r[:4]
    rl.append(f'relationship {tag()}')
    if len(r) > 4 and not r[4]:
        rl.append('\tisActive: false')
    if tc == 'Date':
        rl.append('\tjoinOnDateBehavior: datePartOnly')
    rl.append(f'\tfromColumn: {f}.{fc}')
    rl.append(f'\ttoColumn: {t}.{tc}')
    rl.append('')
w(f'{SM}/definition/relationships.tmdl', '\n'.join(rl))

order = ['CaminhoExcel', 'DataCorte', 'stg_Clientes', 'stg_Gestores'] + [t for t in TABLES if t != 'dCalendario']
w(f'{SM}/definition/model.tmdl', f'''model Model
\tculture: pt-PT
\tdefaultPowerBIDataSourceVersion: powerBI_V3
\tdiscourageImplicitMeasures
\tsourceQueryCulture: pt-PT
\tdataAccessOptions
\t\tlegacyRedirects
\t\treturnErrorValuesAsNull

annotation PBI_QueryOrder = {json.dumps(order, ensure_ascii=False)}

annotation __PBI_TimeIntelligenceEnabled = 0

''' + '\n'.join(f'ref table {t}' for t in ['_Medidas', 'dProjetos', 'dFases', 'dCategorias', 'dCalendario', 'fOrcamento', 'fCustos', 'fTarefas', 'fProgresso']) + '\n')
w(f'{SM}/definition/database.tmdl', 'database\n\tcompatibilityLevel: 1600\n')
w(f'{SM}/definition.pbism', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json',
                                       'version': '4.2', 'settings': {}}, indent=2))
w(f'{SM}/.platform', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json',
                                 'metadata': {'type': 'SemanticModel', 'displayName': NAME}, 'config': {'version': '2.0', 'logicalId': tag()}}, indent=2))

# =====================================================================
# 2. RELATÓRIO (PBIR)
# =====================================================================
BG = '#0B1424'; SIDE = '#070E1C'; CARD = '#121E33'; CARD2 = '#18263F'; LINE = '#22324F'
FG = '#E8EEF7'; FG2 = '#9FB0C8'; FG3 = '#6B7C96'; ORANGE = '#F28C28'; BLUE = '#3B82F6'
PAGES = {'pg_visao_geral': ('Visão Geral', 'Visão Geral do Portefólio de Projetos',
                            'Custos, prazos e projetos que exigem intervenção · para o Diretor de Projetos'),
         'pg_prazos_riscos': ('Prazos e Riscos', 'Prazos, Fases e Riscos',
                              'Onde estão os atrasos e as derrapagens: fases, tarefas, gestores e projetos')}
ORDER = list(PAGES)


def L(v):
    if isinstance(v, bool):
        s = 'true' if v else 'false'
    elif isinstance(v, (int, float)):
        s = f'{v}D'
    else:
        s = "'" + v.replace("'", "''") + "'"
    return {'expr': {'Literal': {'Value': s}}}


def C(h):
    return {'solid': {'color': L(h)}}


def obj(sel=None, **kw):
    o = {'properties': {k: (C(v) if isinstance(v, str) and v.startswith('#') else L(v)) for k, v in kw.items()}}
    if sel:
        o['selector'] = {'id': sel}
    return o


# fundo das páginas
FNT = '/usr/share/fonts/opentype/inter/'
def font(wt, s):
    return ImageFont.truetype(FNT + {'b': 'Inter-Bold.otf', 's': 'Inter-SemiBold.otf', 'r': 'Inter-Regular.otf'}[wt], s)


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


REG = f'{RP}/StaticResources/RegisteredResources'
bg_files = {}
for idx, pid in enumerate(ORDER, 1):
    _, title, sub = PAGES[pid]
    im = Image.new('RGB', (1920, 1080), rgb(BG))
    glow = Image.new('RGB', (1920, 1080), (0, 0, 0)); g = ImageDraw.Draw(glow)
    g.ellipse((1250, -420, 2250, 420), fill=(30, 64, 128)); g.ellipse((300, 760, 1100, 1500), fill=(60, 36, 12))
    im = ImageChops.add(im, glow.filter(ImageFilter.GaussianBlur(160)).point(lambda x: int(x * 0.35)))
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, 259, 1080), fill=rgb(SIDE)); d.line((260, 0, 260, 1080), fill=rgb(LINE)); d.rectangle((0, 0, 4, 1080), fill=rgb(ORANGE))
    # marca (fictícia)
    d.rounded_rectangle((22, 22, 70, 70), 10, fill=rgb(ORANGE))
    d.polygon([(34, 60), (46, 32), (58, 60)], outline=rgb(SIDE), width=4)
    d.text((82, 24), 'Vértice', font=font('b', 22), fill=rgb(FG)); d.text((83, 52), 'CONSTRUÇÕES', font=font('s', 11), fill=rgb(ORANGE))
    d.line((20, 96, 240, 96), fill=rgb(LINE))
    d.text((22, 106), 'NAVEGAÇÃO', font=font('s', 11), fill=rgb(FG3))
    d.text((22, 250), 'FILTROS', font=font('s', 11), fill=rgb(FG3))
    d.line((20, 1004, 240, 1004), fill=rgb(LINE))
    d.text((22, 1016), 'Gestão de Projetos 2024–2025', font=font('s', 12), fill=rgb(FG2))
    d.text((22, 1036), 'Dados fictícios · corte 31/12/2025', font=font('r', 11), fill=rgb(FG3))
    d.text((290, 20), title, font=font('b', 30), fill=rgb(FG))
    d.text((291, 62), sub, font=font('r', 15), fill=rgb(FG2))
    tg = f'PÁGINA {idx} / {len(ORDER)}'; f = font('s', 12); tw = d.textlength(tg, font=f)
    d.rounded_rectangle((1900 - tw - 28, 30, 1900, 58), radius=14, outline=rgb(ORANGE), width=1)
    d.text((1900 - tw - 14, 37), tg, font=f, fill=rgb(ORANGE))
    for x in range(290, 1900):
        t = (x - 290) / 1610
        cc = tuple(int(a * (1 - t) + b * t) for a, b in zip(rgb(ORANGE), rgb(BG)))
        d.point((x, 92), fill=cc); d.point((x, 93), fill=cc)
    fn = f'Fundo_{pid}.png'
    im.save(f'{REG}/{fn}', optimize=True)
    bg_files[pid] = fn

# tema
THEME = 'Tema_Executivo_Escuro.json'
theme = {
    'name': 'Tema Executivo Escuro',
    'dataColors': [ORANGE, BLUE, '#14B8A6', '#A78BFA', '#F43F5E', '#FACC15', '#38BDF8', '#22C55E'],
    'foreground': FG, 'foregroundNeutralSecondary': FG2, 'foregroundNeutralTertiary': FG3, 'foregroundNeutralLight': '#2A3A57',
    'background': CARD, 'backgroundLight': CARD2, 'backgroundNeutral': '#24344F', 'backgroundDark': SIDE,
    'tableAccent': ORANGE, 'shapeStroke': LINE, 'disabledText': FG3, 'good': '#30A46C', 'neutral': '#F5A524', 'bad': '#E5484D',
    'maximum': '#E5484D', 'center': '#F5A524', 'minimum': '#30A46C', 'null': FG3, 'hyperlink': '#60A5FA', 'visitedHyperlink': '#A78BFA',
    'textClasses': {'callout': {'fontSize': 24, 'color': '#FFFFFF'}, 'title': {'fontSize': 12, 'color': FG},
                    'header': {'fontSize': 12, 'color': FG}, 'label': {'fontSize': 10, 'color': FG2}},
    'visualStyles': {
        '*': {'*': {
            'background': [{'show': True, 'color': {'solid': {'color': CARD}}, 'transparency': 0}],
            'border': [{'show': True, 'color': {'solid': {'color': LINE}}, 'radius': 12, 'width': 1}],
            'dropShadow': [{'show': True, 'preset': 'Custom', 'color': {'solid': {'color': '#000000'}}, 'transparency': 65, 'angle': 90, 'shadowDistance': 3, 'shadowBlur': 12, 'shadowSpread': 0}],
            'title': [{'show': True, 'fontColor': {'solid': {'color': FG}}, 'fontSize': 12, 'bold': True}],
            'subTitle': [{'show': False}],
            'visualHeader': [{'background': {'solid': {'color': CARD2}}, 'border': {'solid': {'color': LINE}}, 'foreground': {'solid': {'color': FG}}, 'transparency': 0}],
            'categoryAxis': [{'labelColor': {'solid': {'color': FG2}}, 'gridlineColor': {'solid': {'color': LINE}}, 'titleColor': {'solid': {'color': FG2}}}],
            'valueAxis': [{'labelColor': {'solid': {'color': FG2}}, 'gridlineColor': {'solid': {'color': LINE}}, 'titleColor': {'solid': {'color': FG2}}, 'gridlineStyle': 'dotted'}],
            'legend': [{'show': True, 'position': 'Top', 'labelColor': {'solid': {'color': FG2}}}],
            'labels': [{'color': {'solid': {'color': FG}}}],
            'outspacePane': [{'backgroundColor': {'solid': {'color': CARD}}, 'foregroundColor': {'solid': {'color': FG}}, 'borderColor': {'solid': {'color': LINE}}, 'transparency': 0, 'border': True}],
        }},
        'page': {'*': {'background': [{'color': {'solid': {'color': BG}}, 'transparency': 0}], 'outspace': [{'color': {'solid': {'color': BG}}, 'transparency': 0}]}},
        'pivotTable': {'*': {'stylePreset': [{'name': 'None'}],
                             'grid': [{'gridHorizontal': True, 'gridHorizontalColor': {'solid': {'color': LINE}}, 'gridVertical': False, 'outlineColor': {'solid': {'color': LINE}}, 'rowPadding': 5}],
                             'columnHeaders': [{'fontColor': {'solid': {'color': FG2}}, 'backColor': {'solid': {'color': CARD2}}, 'bold': True}],
                             'rowHeaders': [{'fontColor': {'solid': {'color': FG}}, 'backColor': {'solid': {'color': '#FFFFFF00'}}}],
                             'values': [{'fontColorPrimary': {'solid': {'color': FG}}, 'fontColorSecondary': {'solid': {'color': FG}}, 'backColorPrimary': {'solid': {'color': CARD}}, 'backColorSecondary': {'solid': {'color': '#15233B'}}}],
                             'total': [{'fontColor': {'solid': {'color': ORANGE}}, 'backColor': {'solid': {'color': CARD2}}, 'bold': True}]}},
        'tableEx': {'*': {'stylePreset': [{'name': 'None'}],
                          'grid': [{'gridHorizontal': True, 'gridHorizontalColor': {'solid': {'color': LINE}}, 'gridVertical': False, 'outlineColor': {'solid': {'color': LINE}}, 'rowPadding': 5}],
                          'columnHeaders': [{'fontColor': {'solid': {'color': FG2}}, 'backColor': {'solid': {'color': CARD2}}, 'bold': True}],
                          'values': [{'fontColorPrimary': {'solid': {'color': FG}}, 'fontColorSecondary': {'solid': {'color': FG}}, 'backColorPrimary': {'solid': {'color': CARD}}, 'backColorSecondary': {'solid': {'color': '#15233B'}}}],
                          'total': [{'fontColor': {'solid': {'color': ORANGE}}, 'backColor': {'solid': {'color': CARD2}}, 'bold': True}]}},
        'slicer': {'*': {'general': [{'outlineColor': {'solid': {'color': LINE}}}],
                         'header': [{'show': True, 'fontColor': {'solid': {'color': FG2}}, 'textSize': 10, 'bold': True}],
                         'items': [{'fontColor': {'solid': {'color': FG}}, 'background': {'solid': {'color': CARD2}}, 'textSize': 11}],
                         'title': [{'show': False}], 'dropShadow': [{'show': False}]}},
        'cardVisual': {'*': {'outline': [{'$id': 'default', 'show': False}], 'borderCustom': [{'$id': 'default', 'show': False}],
                             'fillCustom': [{'$id': 'default', 'transparency': 100}], 'label': [{'$id': 'default', 'show': False}],
                             'value': [{'$id': 'default', 'fontColor': {'solid': {'color': '#FFFFFF'}}, 'fontSize': 24, 'bold': True}]}},
        'image': {'*': {'background': [{'show': False}], 'border': [{'show': False}], 'dropShadow': [{'show': False}], 'title': [{'show': False}]}},
        'actionButton': {'*': {'background': [{'show': False}], 'border': [{'show': False}], 'dropShadow': [{'show': False}], 'title': [{'show': False}]}},
    },
}
json.dump(theme, open(f'{REG}/{THEME}', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
shutil.copy(FLUENT, f'{RP}/StaticResources/SharedResources/BaseThemes/Fluent2-CY26SU10.json')
VER = {'visual': '2.14.0', 'report': '3.4.0', 'page': '2.3.1'}
report = {
    '$schema': 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.3.0/schema.json',
    'themeCollection': {'baseTheme': {'name': 'Fluent2-CY26SU10', 'reportVersionAtImport': VER, 'type': 'SharedResources'},
                        'customTheme': {'name': THEME, 'reportVersionAtImport': VER, 'type': 'RegisteredResources'}},
    'objects': {'section': [{'properties': {'verticalAlignment': L('Top')}}], 'outspacePane': [{'properties': {'expanded': L(False)}}]},
    'resourcePackages': [
        {'name': 'SharedResources', 'type': 'SharedResources', 'items': [{'name': 'Fluent2-CY26SU10', 'path': 'BaseThemes/Fluent2-CY26SU10.json', 'type': 'BaseTheme'}]},
        {'name': 'RegisteredResources', 'type': 'RegisteredResources',
         'items': [{'name': THEME, 'path': THEME, 'type': 'CustomTheme'}] + [{'name': f, 'path': f, 'type': 'Image'} for f in bg_files.values()]}],
    'settings': {'useStylableVisualContainerHeader': True, 'exportDataMode': 'AllowSummarized', 'defaultDrillFilterOtherVisuals': True,
                 'allowChangeFilterTypes': True, 'useEnhancedTooltips': True, 'useDefaultAggregateDisplayName': True},
}
D = f'{RP}/definition'
w(f'{D}/report.json', json.dumps(report, ensure_ascii=False))
w(f'{D}/version.json', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json', 'version': '2.0.0'}))
w(f'{D}/pages/pages.json', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json',
                                       'pageOrder': ORDER, 'activePageName': ORDER[0]}))
SCHEMA = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.14.0/schema.json'


def fld(ref):
    ent, prop = ref.split('.', 1)
    if ent == '_Medidas':
        return {'Measure': {'Expression': {'SourceRef': {'Entity': ent}}, 'Property': prop}}
    return {'Column': {'Expression': {'SourceRef': {'Entity': ent}}, 'Property': prop}}


def projection(ref):
    p = {'field': fld(ref), 'queryRef': ref, 'nativeQueryRef': ref.split('.', 1)[1]}
    if not ref.startswith('_Medidas'):
        p['active'] = True
    return p


def container(title=None, show=True, align='left', size=12, color=FG, pad=12, bg=CARD, shadow=True):
    t = dict(show=show, fontColor=color, fontSize=size, bold=True, alignment=align, titleWrap=True)
    if title:
        t['text'] = title
    return {'title': [obj(**t)], 'subTitle': [obj(show=False)],
            'background': [obj(show=True, color=bg, transparency=0)],
            'border': [obj(show=True, color=LINE, radius=12, width=1)],
            'dropShadow': [obj(show=shadow, preset='Custom', color='#000000', transparency=65, angle=90, shadowDistance=3, shadowBlur=12, shadowSpread=0)],
            'padding': [obj(top=pad, bottom=pad, left=pad + 2, right=pad + 2)],
            'visualHeader': [obj(background=CARD2, border=LINE, foreground=FG)]}


class Page:
    def __init__(self, pid):
        self.pid = pid; self.z = 1000; self.tab = 0
        self.dir = f'{D}/pages/{pid}'
        os.makedirs(f'{self.dir}/visuals')
        w(f'{self.dir}/page.json', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json',
                                               'name': pid, 'displayName': PAGES[pid][0], 'displayOption': 'FitToPage', 'height': 1080, 'width': 1920}, ensure_ascii=False))

    def add(self, visual, x, y, wd, ht, z=None, extra=None):
        name = secrets.token_hex(10)
        self.z += 1000; self.tab += 1000
        v = {'$schema': SCHEMA, 'name': name,
             'position': {'x': round(x, 2), 'y': round(y, 2), 'z': z if z is not None else self.z, 'height': round(ht, 2), 'width': round(wd, 2), 'tabOrder': self.tab},
             'visual': visual}
        if extra:
            v.update(extra)
        os.makedirs(f'{self.dir}/visuals/{name}')
        w(f'{self.dir}/visuals/{name}/visual.json', json.dumps(v, ensure_ascii=False))

    def chart(self, vtype, roles, x, y, wd, ht, title=None, objects=None, sort=None, vco=None):
        qs = {r: {'projections': [projection(f) for f in fl]} for r, fl in roles.items()}
        query = {'queryState': qs}
        if sort:
            query['sortDefinition'] = {'sort': [{'field': fld(f), 'direction': dr} for f, dr in sort]}
        vis = {'visualType': vtype, 'query': query, 'objects': objects or {},
               'visualContainerObjects': vco or container(title=title), 'drillFilterOtherVisuals': True}
        if not vis['objects']:
            vis.pop('objects')
        self.add(vis, x, y, wd, ht)

    def kpi(self, measure, x, y, wd, ht, title):
        o = {'value': [obj('default', horizontalAlignment='center', fontColor='#FFFFFF', fontSize=26, bold=True)],
             'label': [obj('default', show=False)], 'outline': [obj('default', show=False)]}
        vco = container(title=title, align='center', size=11, color=FG2, pad=10)
        self.chart('cardVisual', {'Data': [measure]}, x, y, wd, ht, objects=o, vco=vco)

    def slicer(self, field, x, y, wd, ht, title):
        o = {'data': [obj(mode='Dropdown')], 'header': [obj(show=True, fontColor=FG2, textSize=10, bold=True, text=title)],
             'items': [obj(fontColor=FG, background=CARD2, textSize=11)], 'general': [obj(outlineColor=LINE, orientation=0)]}
        vco = container(show=False, pad=8, bg='#0E1A2E', shadow=False)
        vco['border'] = [obj(show=True, color=LINE, radius=10, width=1)]
        self.chart('slicer', {'Values': [field]}, x, y, wd, ht, objects=o, vco=vco)

    def background(self):
        fn = bg_files[self.pid]
        self.add({'visualType': 'image',
                  'objects': {'image': [{'properties': {'sourceFile': {'image': {
                      'name': L(fn), 'url': {'expr': {'ResourcePackageItem': {'PackageName': 'RegisteredResources', 'PackageType': 1, 'ItemName': fn}}},
                      'scaling': L('Fit')}}}}]},
                  'visualContainerObjects': {'title': [obj(show=False)], 'background': [obj(show=False)], 'border': [obj(show=False)],
                                             'dropShadow': [obj(show=False)], 'padding': [obj(top=0, bottom=0, left=0, right=0)], 'visualHeader': [obj(show=False)]},
                  'drillFilterOtherVisuals': True}, 0, 0, 1920, 1080, z=0)

    def button(self, text, x, y, wd, ht, link, active=False, ghost=False):
        if active:
            fd, fh, td, th, lc = ORANGE, '#F59E3D', '#0B1424', '#0B1424', ORANGE
        elif ghost:
            fd, fh, td, th, lc = '#0E1A2E', ORANGE, ORANGE, '#0B1424', ORANGE
        else:
            fd, fh, td, th, lc = '#111D33', '#1E3150', '#C9D4E5', '#FFFFFF', LINE
        o = {'icon': [obj(show=False), obj('default', shapeType='blank')],
             'text': [obj(show=True), obj('default', text=text, fontColor=td, fontSize=11, bold=True, alignment='center' if ghost else 'left',
                                          leftMargin=18, rightMargin=12, topMargin=6, bottomMargin=6),
                      obj('hover', fontColor=th), obj('press', fontColor=th)],
             'fill': [obj(show=True), obj('default', fillColor=fd, transparency=0), obj('hover', fillColor=fh, transparency=0), obj('press', fillColor=fh, transparency=0)],
             'outline': [obj(show=True), obj('default', lineColor=lc, weight=1, transparency=0), obj('hover', lineColor=ORANGE, weight=1, transparency=0)],
             'shape': [obj('default', roundEdge=10)]}
        self.add({'visualType': 'actionButton', 'objects': o,
                  'visualContainerObjects': {'visualLink': [link], 'title': [obj(show=False)], 'background': [obj(show=False)],
                                             'border': [obj(show=False)], 'dropShadow': [obj(show=False)], 'visualHeader': [obj(show=False)]},
                  'drillFilterOtherVisuals': True}, x, y, wd, ht, z=90000, extra={'howCreated': 'InsertVisualButton'})

    def sidebar(self):
        self.background()
        for i, target in enumerate(ORDER):
            link = obj(show=False) if target == self.pid else obj(show=True, type='PageNavigation', navigationSection=target)
            self.button(f'0{i + 1}   {PAGES[target][0]}', 20, 128 + i * 54, 220, 46, link, active=(target == self.pid))
        self.button('Limpar todos os filtros', 20, 274, 220, 44, obj(show=True, type='ClearAllSlicers'), ghost=True)
        for i, (f, t) in enumerate([('dCalendario.Ano', 'Ano'), ('dProjetos.Tipo_Projeto', 'Tipo de projeto'),
                                    ('dProjetos.Gestor', 'Gestor de projeto'), ('dProjetos.Estado', 'Estado do projeto'),
                                    ('dFases.Fase', 'Fase da obra')]):
            self.slicer(f, 20, 336 + i * 108, 220, 96, t)


def grid(n, x0=290, x1=1900, gap=14):
    wd = (x1 - x0 - gap * (n - 1)) / n
    return [(x0 + i * (wd + gap), wd) for i in range(n)]


def fcolor(measure, target):  # formatação condicional da cor do texto a partir de uma medida
    return {'properties': {'fontColor': {'solid': {'color': {'expr': {'Measure': {'Expression': {'SourceRef': {'Entity': '_Medidas'}}, 'Property': measure}}}}}},
            'selector': {'data': [{'dataViewWildcard': {'matchingOption': 1}}], 'metadata': target}}


AX = {'categoryAxis': [obj(labelColor=FG2, fontSize=10, gridlineShow=False)],
      'valueAxis': [obj(labelColor=FG2, fontSize=10, gridlineColor=LINE, gridlineStyle='dotted')]}
TBL = lambda: {'columnHeaders': [obj(fontColor=FG2, backColor=CARD2, bold=True, fontSize=10)],
               'values': [obj(fontColorPrimary=FG, fontColorSecondary=FG, backColorPrimary=CARD, backColorSecondary='#15233B', fontSize=10)],
               'grid': [obj(gridHorizontal=True, gridHorizontalColor=LINE, gridVertical=False, outlineColor=LINE, rowPadding=4)]}

# ---------------- Página 1: Visão Geral ----------------
p = Page('pg_visao_geral'); p.sidebar()
kpis = [('_Medidas.Nº Projetos', 'Nº de projetos'), ('_Medidas.% Projetos Atrasados', '% de projetos atrasados'),
        ('_Medidas.Custo Real Acumulado', 'Custo real acumulado'), ('_Medidas.Desvio de Custo %', 'Desvio de custo (vs valor ganho)'),
        ('_Medidas.SPI', 'SPI · índice de prazo'), ('_Medidas.Projetos Intervenção Prioritária', 'Projetos a intervir')]
for (x, wd), (m, t) in zip(grid(6), kpis):
    p.kpi(m, x, 108, wd, 112, t)
p.chart('lineClusteredColumnComboChart', {'Category': ['dCalendario.MesAno'], 'Y': ['_Medidas.Custo Real'], 'Y2': ['_Medidas.Orçamento até à Data']},
        290, 234, 1000, 396, 'Orçamento planeado vs custo real por mês (€)',
        objects={**AX, 'dataPoint': [{'properties': {'fill': C(ORANGE)}, 'selector': {'metadata': '_Medidas.Custo Real'}},
                                     {'properties': {'fill': C(BLUE)}, 'selector': {'metadata': '_Medidas.Orçamento até à Data'}}],
                 'legend': [obj(show=True, position='Top', labelColor=FG2, fontSize=11)]},
        sort=[('dCalendario.MesAno', 'Ascending')])
p.chart('clusteredBarChart', {'Category': ['dProjetos.Tipo_Projeto'], 'Y': ['_Medidas.Desvio de Custo %']}, 1304, 234, 596, 396,
        'Desvio de custo % por tipo de projeto',
        objects={'categoryAxis': [obj(labelColor=FG, fontSize=11)], 'valueAxis': [obj(show=False)], 'labels': [obj(show=True, color=FG, fontSize=11)],
                 'dataPoint': [obj(fill=ORANGE)]},
        sort=[('_Medidas.Desvio de Custo %', 'Descending')])
t_obj = TBL(); t_obj['values'] += [fcolor('Cor Desvio', '_Medidas.Desvio de Custo %'), fcolor('Cor SPI', '_Medidas.SPI'),
                                    fcolor('Cor Intervenção', '_Medidas.Estado de Intervenção')]
p.chart('tableEx', {'Values': ['dProjetos.Projeto', 'dProjetos.Gestor', 'dProjetos.Estado', '_Medidas.Dias de Atraso',
                               '_Medidas.Desvio de Custo %', '_Medidas.SPI', '_Medidas.Estado de Intervenção']},
        290, 644, 1000, 416, 'Projetos que exigem intervenção prioritária (ordenado por desvio de custo)', objects=t_obj,
        sort=[('_Medidas.Desvio de Custo %', 'Descending')])
p.chart('lineChart', {'Category': ['dCalendario.MesAno'], 'Y': ['_Medidas.Progresso Previsto %', '_Medidas.Progresso Real %']},
        1304, 644, 596, 416, 'Progresso previsto vs progresso real (%)',
        objects={**AX, 'legend': [obj(show=True, position='Top', labelColor=FG2, fontSize=11)],
                 'dataPoint': [{'properties': {'fill': C(BLUE)}, 'selector': {'metadata': '_Medidas.Progresso Previsto %'}},
                               {'properties': {'fill': C(ORANGE)}, 'selector': {'metadata': '_Medidas.Progresso Real %'}}],
                 'lineStyles': [obj(showMarker=True, strokeWidth=3)]},
        sort=[('dCalendario.MesAno', 'Ascending')])

# ---------------- Página 2: Prazos e Riscos ----------------
p = Page('pg_prazos_riscos'); p.sidebar()
kpis = [('_Medidas.Nº Tarefas', 'Nº de tarefas'), ('_Medidas.% Tarefas Atrasadas', '% de tarefas atrasadas'),
        ('_Medidas.Tarefas Alto Risco', 'Tarefas de risco alto'), ('_Medidas.Dias de Atraso Médio', 'Dias de atraso médio (projetos)'),
        ('_Medidas.Desvio de Horas %', 'Desvio de horas'), ('_Medidas.CPI', 'CPI · índice de custo')]
for (x, wd), (m, t) in zip(grid(6), kpis):
    p.kpi(m, x, 108, wd, 112, t)
p.chart('clusteredColumnChart', {'Category': ['dFases.Fase'], 'Y': ['_Medidas.Desvio de Custo %', '_Medidas.% Tarefas Alto Risco']},
        290, 234, 860, 396, 'Desvio de custo % e % de tarefas de risco alto por fase da obra',
        objects={**AX, 'labels': [obj(show=True, color=FG, fontSize=10)], 'legend': [obj(show=True, position='Top', labelColor=FG2, fontSize=11)],
                 'dataPoint': [{'properties': {'fill': C(ORANGE)}, 'selector': {'metadata': '_Medidas.Desvio de Custo %'}},
                               {'properties': {'fill': C(BLUE)}, 'selector': {'metadata': '_Medidas.% Tarefas Alto Risco'}}]},
        sort=[('dFases.Fase', 'Ascending')])
m_obj = TBL(); m_obj['rowHeaders'] = [obj(fontColor=FG, fontSize=10)]; m_obj['total'] = [obj(fontColor=ORANGE, backColor=CARD2, bold=True, fontSize=10)]
p.chart('pivotTable', {'Rows': ['dFases.Fase'], 'Columns': ['fTarefas.Risco'], 'Values': ['_Medidas.Nº Tarefas']},
        1164, 234, 736, 396, 'Nº de tarefas por fase e nível de risco', objects=m_obj)
p.chart('scatterChart', {'Category': ['dProjetos.Projeto'], 'X': ['_Medidas.Dias de Atraso'], 'Y': ['_Medidas.Desvio de Custo %'],
                         'Size': ['_Medidas.Orçamento Contratado']},
        290, 644, 860, 416, 'Projetos: atraso (dias) vs desvio de custo % · tamanho = orçamento',
        objects={**AX, 'dataPoint': [obj(fill=ORANGE)], 'categoryLabels': [obj(show=False)]})
p.chart('donutChart', {'Category': ['fTarefas.Estado'], 'Y': ['_Medidas.Nº Tarefas']}, 1164, 644, 361, 416, 'Tarefas por estado',
        objects={'legend': [obj(show=True, position='Bottom', labelColor=FG2, fontSize=10)], 'labels': [obj(show=True, color=FG, fontSize=10)]})
p.chart('clusteredBarChart', {'Category': ['dProjetos.Gestor'], 'Y': ['_Medidas.Desvio de Custo %']}, 1539, 644, 361, 416,
        'Desvio de custo % por gestor',
        objects={'categoryAxis': [obj(labelColor=FG, fontSize=10)], 'valueAxis': [obj(show=False)], 'labels': [obj(show=True, color=FG, fontSize=10)],
                 'dataPoint': [obj(fill=BLUE)]},
        sort=[('_Medidas.Desvio de Custo %', 'Descending')])

w(f'{RP}/definition.pbir', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json',
                                       'version': '4.0', 'datasetReference': {'byPath': {'path': f'../{NAME}.SemanticModel'}}}, indent=2))
w(f'{RP}/.platform', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json',
                                 'metadata': {'type': 'Report', 'displayName': NAME}, 'config': {'version': '2.0', 'logicalId': tag()}}, indent=2))
w(f'{OUT}/{NAME}.pbip', json.dumps({'$schema': 'https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json',
                                   'version': '1.0', 'artifacts': [{'report': {'path': f'{NAME}.Report'}}], 'settings': {'enableAutoRecovery': True}}, indent=2))
w(f'{OUT}/.gitignore', '**/.pbi/localSettings.json\n**/.pbi/cache.abf\n')
print('PBIP criado com', N_MEDIDAS, 'medidas')

# exportar definições para a documentação
json.dump({'tables': {t: {'cols': [c[0] for c in v[0]], 'types': [c[1] for c in v[0]], 'hidden': [bool(c[2].get('isHidden')) for c in v[0]], 'src': v[1].strip(), 'kind': v[2]} for t, v in TABLES.items()},
           'measures': M, 'rels': RELS}, open(f'{BASE}/scripts/modelo.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
